#!/usr/bin/env python3
"""Create the conceptual method schematic used in the main manuscript."""

from pathlib import Path
from archive_paths import FIGURES

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
OUTPUT = FIGURES / "method_schematic.png"

ORANGE = "#D55E00"
BLUE = "#0072B2"
GREEN = "#009E73"
GRAY = "#8A8A8A"
LIGHT = "#D7D7D7"
DARK = "#2A2A2A"


def edge(ax, a, b, color=LIGHT, width=1.5, arrow=False, alpha=1.0):
    props = dict(
        arrowstyle="-|>" if arrow else "-",
        color=color,
        linewidth=width,
        alpha=alpha,
        shrinkA=7,
        shrinkB=7,
        mutation_scale=10,
    )
    ax.annotate("", xy=b, xytext=a, arrowprops=props, zorder=1)


def node(ax, xy, color, marker="o", size=170, edgecolor="white", linewidth=1.2):
    ax.scatter(
        [xy[0]], [xy[1]], s=size, c=[color], marker=marker,
        edgecolors=edgecolor, linewidths=linewidth, zorder=3
    )


def network_panel(ax, delayed=False):
    pos = {
        0: (0.08, 0.52), 1: (0.32, 0.52), 2: (0.56, 0.52),
        3: (0.80, 0.52), 4: (0.32, 0.82), 5: (0.56, 0.19),
        6: (0.81, 0.82),
    }
    links = [(0, 1), (1, 2), (2, 3), (1, 4), (2, 5), (2, 6)]
    for i, j in links:
        highlight = (i, j) == (0, 1) if not delayed else (i, j) in {(0, 1), (1, 2), (2, 3)}
        edge(
            ax, pos[i], pos[j],
            color=ORANGE if highlight else LIGHT,
            width=2.8 if highlight else 1.4,
            arrow=delayed and highlight,
        )
    for index, xy in pos.items():
        if index == 0:
            node(ax, xy, ORANGE, marker="s", size=190)
        elif (not delayed and index == 1) or (delayed and index == 3):
            node(ax, xy, BLUE, marker="o", size=205)
        elif delayed and index in (1, 2):
            node(ax, xy, "white", marker="o", size=155, edgecolor=ORANGE, linewidth=2.0)
        else:
            node(ax, xy, GRAY, marker="o", size=120)

    ax.text(pos[0][0] - 0.015, 0.34, "treated", ha="center", va="top", color=DARK)
    target = pos[3] if delayed else pos[1]
    target_x = target[0] + (0.035 if not delayed else 0.0)
    ax.text(target_x, 0.34, "focal response", ha="center", va="top", color=DARK)
    if delayed:
        ax.text(0.44, 0.70, "social relays", ha="center", va="bottom", color=ORANGE)
        ax.text(0.49, 0.02, "tail detector: paths of 2+ links", ha="center", va="bottom", color=DARK)
        ax.text(0.49, -0.09, "one-hop shadow removed", ha="center", va="bottom", color=GRAY)
    else:
        ax.text(0.44, 0.02, "one-hop detector: immediate link", ha="center", va="bottom", color=DARK)
    ax.set_xlim(-0.03, 0.96)
    ax.set_ylim(-0.12, 1.0)
    ax.axis("off")


def calibration_panel(ax):
    rng = np.random.default_rng(20260831)
    detector_x = np.arange(7)
    scores = np.array([1.15, 2.10, 1.58, 1.02, 0.64, 0.42, 0.24])
    colors = [BLUE] + [GREEN] * 6
    ax.bar(detector_x, scores, width=0.62, color=colors, alpha=0.88, zorder=2)
    ax.scatter([1], [scores[1]], marker="D", s=52, color=DARK, zorder=4)
    ax.text(1, 2.40, "observed maximum", ha="center", va="center", color=DARK)
    ax.axhline(0, color=DARK, linewidth=0.8)
    ax.set_xticks(detector_x, ["1-hop", ".2", ".4", ".6", ".75", ".85", ".92"])
    ax.set_ylabel("standardized response")
    ax.set_xlabel("detector ($\lambda$ for tail components)")
    ax.set_ylim(0, 2.7)
    ax.set_yticks([0, 1, 2])
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=LIGHT, linewidth=0.7, zorder=0)

    inset = ax.inset_axes([0.63, 0.57, 0.34, 0.34])
    randomized_maxima = np.sort(rng.normal(1.08, 0.33, 38))
    y = np.linspace(0.12, 0.88, randomized_maxima.size)
    inset.scatter(randomized_maxima, y, s=12, color=GRAY, alpha=0.75)
    inset.axvline(scores[1], color=DARK, linewidth=1.5)
    inset.text(scores[1] - 0.04, 0.92, "observed", ha="right", va="top", color=DARK)
    inset.set_xlabel("randomized maxima")
    inset.set_yticks([])
    inset.spines[["top", "right", "left"]].set_visible(False)
    inset.set_xlim(0.25, 2.35)
    inset.set_xticks([0.5, 1.0, 1.5, 2.0])


def main():
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.5,
            "ytick.labelsize": 8.5,
        }
    )
    fig, axes = plt.subplots(1, 3, figsize=(12.4, 3.45), gridspec_kw={"width_ratios": [1, 1, 1.25]})
    network_panel(axes[0], delayed=False)
    network_panel(axes[1], delayed=True)
    calibration_panel(axes[2])
    titles = ["(a) Immediate response", "(b) Delayed response", "(c) Calibrate the whole scan"]
    for ax, title in zip(axes, titles):
        ax.set_title(title, loc="left", fontsize=11, fontweight="bold", color=DARK, pad=8)
    fig.subplots_adjust(left=0.035, right=0.985, bottom=0.19, top=0.87, wspace=0.28)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUTPUT, dpi=320, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("Wrote figures/method_schematic.png")


if __name__ == "__main__":
    main()
