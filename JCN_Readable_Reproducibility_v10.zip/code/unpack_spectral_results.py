"""Restore spectral reference CSVs without rounding (not a new experiment).
Usage: python code/unpack_spectral_results.py aggregate_results.csv results/reference
"""
from pathlib import Path
import argparse
import csv
from collections import defaultdict

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('aggregate',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    groups=defaultdict(list)
    with args.aggregate.open(newline='') as handle:
        for row in csv.DictReader(handle):
            if row.get('spectral_relative_path'):
                groups[row['spectral_relative_path']].append(row)
    for relative,rows in groups.items():
        path=Path(relative)
        if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe reference path')
        fields=rows[0]['spectral_fields'].split('|')
        assert all(row['spectral_fields'].split('|')==fields for row in rows)
        target=args.output/path
        if target.exists():raise FileExistsError(f'Refusing to overwrite {target}')
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('w',newline='') as handle:
            writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader()
            writer.writerows({key:row[key] for key in fields} for row in rows)
    print('Restored',len(groups),'reference tables without numeric conversion')

if __name__=='__main__':main()
