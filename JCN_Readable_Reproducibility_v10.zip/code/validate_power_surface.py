#!/usr/bin/env python3
"""Power surface over sample size, effect strength, graph, and cascade depth."""

from __future__ import annotations

import csv
import json
import math
import time
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import networkx as nx
import numpy as np
from scipy import stats

from validate_diffusion_kernel_test import (
    generate_graph,
    normalized_adjacency,
    spectral_kernels,
    tail_kernel_from_spectrum,
)
from validate_submission_comparators import method_pvalues


OUTPUT = output_dir("results_power_surface")
N_VALUES = (120, 240, 480)
THETA_VALUES = (0.5, 1.0, 1.5)
DELTAS = (0.3, 0.6)
KINDS = ("ER", "SBM", "BA")
METHODS = ("elc", "score", "one_hop", "adaptive")
LAMBDAS = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)
GRAPH_REPLICATES = 20
ASSIGNMENTS_PER_GRAPH = 24
RANDOMIZATIONS = 399
PROBABILITY = 0.4
DIRECT_EFFECT = 0.5


def interval(values: np.ndarray) -> tuple[float, float]:
    mean = float(np.mean(values))
    critical = float(stats.t.ppf(0.975, len(values) - 1))
    half = critical * float(np.std(values, ddof=1) / math.sqrt(len(values)))
    return max(0.0, mean - half), min(1.0, mean + half)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    graph_rng = np.random.default_rng(141421)
    simulation_rng = np.random.default_rng(173205)
    graph_rows: list[dict[str, object]] = []

    for n in N_VALUES:
        for kind in KINDS:
            for graph_index in range(GRAPH_REPLICATES):
                graph_seed = int(graph_rng.integers(0, 2**31 - 1))
                graph = generate_graph(kind, n, graph_seed)
                adjacency = nx.to_numpy_array(graph, dtype=float)
                normalized = normalized_adjacency(graph)
                kernels, eigenvalues, eigenvectors = spectral_kernels(
                    normalized, LAMBDAS
                )
                split = np.random.default_rng(graph_seed + 104729).permutation(n)
                focal = np.sort(split[: n // 2])
                auxiliary = np.sort(split[n // 2 :])
                cross = kernels[:, focal][:, :, auxiliary].copy()
                local = cross[0]
                local_energy = float(np.sum(local**2))
                for index in range(1, len(cross)):
                    cross[index] -= (
                        float(np.sum(cross[index] * local))
                        / max(local_energy, 1e-14)
                    ) * local
                adjacency_ff = adjacency[np.ix_(focal, focal)]
                adjacency_cross = adjacency[np.ix_(focal, auxiliary)]
                focal_degree = adjacency[focal].sum(axis=1)

                for delta in DELTAS:
                    causal_kernel = tail_kernel_from_spectrum(
                        eigenvalues, eigenvectors, delta
                    )
                    causal_kernel *= math.sqrt(n) / np.linalg.norm(
                        causal_kernel, ord="fro"
                    )
                    oracle = tail_kernel_from_spectrum(
                        eigenvalues, eigenvectors, delta
                    )[np.ix_(focal, auxiliary)]
                    oracle -= (
                        float(np.sum(oracle * local)) / max(local_energy, 1e-14)
                    ) * local
                    for theta in THETA_VALUES:
                        scenario_seed = int(simulation_rng.integers(0, 2**63 - 1))
                        rng = np.random.default_rng(scenario_seed)
                        treatment = rng.binomial(
                            1, PROBABILITY, size=(ASSIGNMENTS_PER_GRAPH, n)
                        ).astype(float)
                        error = rng.normal(size=(ASSIGNMENTS_PER_GRAPH, n))
                        outcome = (
                            DIRECT_EFFECT * treatment
                            + theta * ((treatment - PROBABILITY) @ causal_kernel.T)
                            + error
                        )
                        pvalues = method_pvalues(
                            outcome[:, focal],
                            treatment[:, focal],
                            treatment[:, auxiliary],
                            cross,
                            oracle,
                            adjacency_ff,
                            adjacency_cross,
                            focal_degree,
                            PROBABILITY,
                            RANDOMIZATIONS,
                            rng,
                        )
                        for method in METHODS:
                            graph_rows.append(
                                {
                                    "n": n,
                                    "graph": kind,
                                    "graph_index": graph_index,
                                    "graph_seed": graph_seed,
                                    "delta": delta,
                                    "theta": theta,
                                    "method": method,
                                    "rejection_rate": float(
                                        np.mean(pvalues[method] <= 0.05)
                                    ),
                                    "datasets": ASSIGNMENTS_PER_GRAPH,
                                }
                            )

    with (OUTPUT / "graph_level_rates.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(graph_rows[0]))
        writer.writeheader()
        writer.writerows(graph_rows)

    summary: list[dict[str, object]] = []
    for n in N_VALUES:
        for kind in KINDS:
            for delta in DELTAS:
                for theta in THETA_VALUES:
                    for method in METHODS:
                        rates = np.asarray(
                            [
                                row["rejection_rate"]
                                for row in graph_rows
                                if row["n"] == n
                                and row["graph"] == kind
                                and row["delta"] == delta
                                and row["theta"] == theta
                                and row["method"] == method
                            ],
                            dtype=float,
                        )
                        low, high = interval(rates)
                        summary.append(
                            {
                                "n": n,
                                "graph": kind,
                                "delta": delta,
                                "theta": theta,
                                "method": method,
                                "power": float(np.mean(rates)),
                                "cluster_ci_low": low,
                                "cluster_ci_high": high,
                                "graph_replicates": GRAPH_REPLICATES,
                                "datasets": GRAPH_REPLICATES
                                * ASSIGNMENTS_PER_GRAPH,
                            }
                        )
    with (OUTPUT / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    with (OUTPUT / "config.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "n_values": N_VALUES,
                "theta_values": THETA_VALUES,
                "deltas": DELTAS,
                "graph_replicates": GRAPH_REPLICATES,
                "assignments_per_graph": ASSIGNMENTS_PER_GRAPH,
                "randomizations": RANDOMIZATIONS,
                "elapsed_seconds": time.perf_counter() - started,
            },
            handle,
            indent=2,
        )
    print(f"rows={len(summary)} elapsed={time.perf_counter() - started:.2f}s")


if __name__ == "__main__":
    main()
