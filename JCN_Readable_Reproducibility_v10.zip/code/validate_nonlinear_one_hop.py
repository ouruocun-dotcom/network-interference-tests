#!/usr/bin/env python3
"""Specificity audit for orthogonal tails under nonlinear one-hop effects."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import numpy as np

from validate_diffusion_kernel_test import (
    cluster_interval,
    generate_graph,
    normalized_adjacency,
    spectral_kernels,
)
from validate_one_hop_negative_control import pvalues


N = 240
GRAPH_REPLICATES = 25
ASSIGNMENTS_PER_GRAPH = 32
PROBABILITY = 0.4
LAMBDAS = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)
OUTPUT = output_dir("results_nonlinear_one_hop")
SCENARIOS = ("linear", "threshold", "saturation", "treatment_interaction")


def match_rms(values: np.ndarray, target: float) -> np.ndarray:
    centered = values - values.mean(axis=1, keepdims=True)
    rms = float(np.sqrt(np.mean(centered**2)))
    return centered * (target / max(rms, 1e-14))


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    graph_rng = np.random.default_rng(264575)
    simulation_rng = np.random.default_rng(316228)
    rows: list[dict[str, object]] = []

    for kind in ("ER", "SBM", "BA"):
        for graph_index in range(GRAPH_REPLICATES):
            graph_seed = int(graph_rng.integers(0, 2**31 - 1))
            graph = generate_graph(kind, N, graph_seed)
            normalized = normalized_adjacency(graph)
            kernels, _, _ = spectral_kernels(normalized, LAMBDAS)
            split = np.random.default_rng(graph_seed + 104729).permutation(N)
            focal = np.sort(split[: N // 2])
            auxiliary = np.sort(split[N // 2 :])
            cross = kernels[:, focal][:, :, auxiliary].copy()
            local_cross = cross[0]
            local_energy = float(np.sum(local_cross**2))
            for index in range(1, len(cross)):
                cross[index] -= (
                    float(np.sum(cross[index] * local_cross))
                    / max(local_energy, 1e-14)
                ) * local_cross

            local_effect = normalized.copy()
            np.fill_diagonal(local_effect, 0.0)
            local_effect *= math.sqrt(N) / np.linalg.norm(local_effect, ord="fro")
            treatment = simulation_rng.binomial(
                1, PROBABILITY, size=(ASSIGNMENTS_PER_GRAPH, N)
            ).astype(float)
            error = simulation_rng.normal(size=(ASSIGNMENTS_PER_GRAPH, N))
            linear = (treatment - PROBABILITY) @ local_effect.T
            target_rms = float(np.sqrt(np.mean(linear**2)))
            effects = {
                "linear": linear,
                "threshold": match_rms((linear > 0.0).astype(float), target_rms),
                "saturation": match_rms(np.tanh(2.0 * linear), target_rms),
                "treatment_interaction": match_rms(
                    linear * (1.0 + 0.75 * treatment), target_rms
                ),
            }
            common_randomization_seed = int(simulation_rng.integers(0, 2**63 - 1))
            for scenario in SCENARIOS:
                outcome = 0.5 * treatment + effects[scenario] + error
                local_p, tail_p, adaptive_p = pvalues(
                    outcome[:, focal],
                    treatment[:, auxiliary],
                    cross,
                    np.random.default_rng(common_randomization_seed),
                )
                for method, values in (
                    ("one_hop", local_p),
                    ("orthogonal_tail", tail_p),
                    ("adaptive", adaptive_p),
                ):
                    for replicate, value in enumerate(values):
                        rows.append(
                            {
                                "graph": kind,
                                "graph_index": graph_index,
                                "graph_seed": graph_seed,
                                "scenario": scenario,
                                "method": method,
                                "replicate": replicate,
                                "pvalue": float(value),
                            }
                        )

    with (OUTPUT / "replicate_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = []
    for kind in ("ER", "SBM", "BA"):
        for scenario in SCENARIOS:
            for method in ("one_hop", "orthogonal_tail", "adaptive"):
                graph_rates = []
                for graph_index in range(GRAPH_REPLICATES):
                    values = np.asarray(
                        [
                            row["pvalue"]
                            for row in rows
                            if row["graph"] == kind
                            and row["graph_index"] == graph_index
                            and row["scenario"] == scenario
                            and row["method"] == method
                        ],
                        dtype=float,
                    )
                    graph_rates.append(float(np.mean(values <= 0.05)))
                low, high = cluster_interval(np.asarray(graph_rates))
                summary.append(
                    {
                        "graph": kind,
                        "scenario": scenario,
                        "method": method,
                        "rejection_rate": float(np.mean(graph_rates)),
                        "cluster_ci_low": low,
                        "cluster_ci_high": high,
                        "datasets": GRAPH_REPLICATES * ASSIGNMENTS_PER_GRAPH,
                    }
                )
    with (OUTPUT / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
