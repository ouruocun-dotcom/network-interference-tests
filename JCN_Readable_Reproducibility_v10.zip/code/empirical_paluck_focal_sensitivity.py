#!/usr/bin/env python3
"""Sensitivity of the wristband result to outcome-free focal-set rules."""

from __future__ import annotations

import json
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import numpy as np
import pandas as pd

from empirical_paluck_direction_sensitivity import clean_school
from empirical_paluck_test import (
    LAMBDAS,
    kernel_family,
    normalized_adjacency,
    randomization_matrix,
    standardize_scores,
    valid_numeric,
)


CACHE = output_dir("results_paluck_primary_50k") / "decoded_needed.pkl"
OUTPUT = output_dir("results_paluck_focal_sensitivity_50k")
RANDOMIZATIONS = 49_999
SEED = 20260902
RULES = ("all_ineligible", "within_one_hop", "within_two_hops")


def piece(school: pd.DataFrame, rule: str) -> dict | None:
    school = clean_school(school)
    ids = school.ID.to_numpy(dtype=int)
    index = {value: i for i, value in enumerate(ids)}
    adjacency = np.zeros((len(ids), len(ids)), dtype=float)
    for source, (_, row) in enumerate(school.iterrows()):
        for column in (f"ST{i}" for i in range(1, 11)):
            value = row[column]
            target = index.get(int(value)) if np.isfinite(value) and value >= 0 else None
            if target is not None and target != source:
                adjacency[source, target] = adjacency[target, source] = 1.0
    treatment = school.TREAT.to_numpy(dtype=float)
    strata = school.STRB.to_numpy(dtype=float)
    outcome = school.WRISTOW2.to_numpy(dtype=float)
    focal = np.flatnonzero(treatment == 0)
    auxiliary = np.flatnonzero(
        np.isin(treatment, (1, 2)) & np.isfinite(strata) & (strata > 0)
    )
    if rule == "within_one_hop":
        focal = focal[adjacency[np.ix_(focal, auxiliary)].sum(axis=1) > 0]
    elif rule == "within_two_hops":
        reachable = adjacency[:, auxiliary].sum(axis=1) + (adjacency @ adjacency[:, auxiliary]).sum(axis=1)
        focal = focal[reachable[focal] > 0]
    elif rule != "all_ineligible":
        raise ValueError(rule)
    if len(focal) == 0 or len(auxiliary) == 0:
        return None
    if not np.all(valid_numeric(outcome[focal])):
        raise ValueError("WRISTOW2 is incomplete for the outcome-free focal set")
    kernels = kernel_family(normalized_adjacency(adjacency))[:, focal][:, :, auxiliary]
    kernels = kernels.copy()
    local = kernels[0]
    energy = float(np.sum(local**2))
    for k in range(1, len(kernels)):
        kernels[k] -= float(np.sum(kernels[k] * local)) / max(energy, 1e-14) * local
    return {
        "observed": (treatment[auxiliary] == 1).astype(float),
        "weights": np.einsum("f,lfa->al", outcome[focal], kernels, optimize=True),
        "blocks": [(int(school.iloc[i].SCHID), int(strata[i])) for i in auxiliary],
        "focal": len(focal),
    }


def combine(frame: pd.DataFrame, rule: str) -> dict:
    treated = frame[frame.SCHTREAT == 1]
    pieces = [
        piece(treated[treated.SCHID == school].copy(), rule)
        for school in sorted(treated.SCHID.dropna().unique())
    ]
    pieces = [value for value in pieces if value is not None]
    return {
        "observed": np.concatenate([value["observed"] for value in pieces]),
        "weights": np.concatenate([value["weights"] for value in pieces], axis=0),
        "blocks": [label for value in pieces for label in value["blocks"]],
        "focal": int(sum(value["focal"] for value in pieces)),
        "schools": len(pieces),
    }


def pvalue(statistic: np.ndarray) -> float:
    return float(np.mean(statistic >= statistic[0] - 1e-12))


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    frame = pd.read_pickle(CACHE)
    analyses = {rule: combine(frame, rule) for rule in RULES}
    reference = analyses["all_ineligible"]
    assignments, probabilities = randomization_matrix(
        reference["observed"], reference["blocks"], RANDOMIZATIONS, np.random.default_rng(SEED)
    )
    centered = assignments.astype(float) - probabilities[None, :]
    results = []
    for rule, analysis in analyses.items():
        if not np.array_equal(analysis["observed"], reference["observed"]):
            raise ValueError("Auxiliary assignment changed across focal rules")
        scores = centered @ analysis["weights"]
        z, valid_components = standardize_scores(scores)
        if not valid_components[0]:
            raise ValueError("the one-hop component has zero conditional variance")
        adaptive = np.max(z[:, valid_components], axis=1)
        results.append(
            {
                "rule": rule,
                "schools": analysis["schools"],
                "focal_units": analysis["focal"],
                "p_one_hop": pvalue(z[:, 0]),
                "p_adaptive": pvalue(adaptive),
                "p_adaptive_two_sided": pvalue(
                    np.max(np.abs(z[:, valid_components]), axis=1)
                ),
                "observed_adaptive_z": float(adaptive[0]),
                "selected_lambda": float(LAMBDAS[int(np.nanargmax(z[0]))]),
            }
        )
    payload = {"randomizations": RANDOMIZATIONS, "seed": SEED, "results": results}
    with (OUTPUT / "focal_sensitivity.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
