#!/usr/bin/env python3
"""Robustness of randomization-test power to network edge mismeasurement."""

from __future__ import annotations

import csv
import json
import math
import time
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import networkx as nx
import numpy as np
from scipy import stats

from validate_diffusion_kernel_test import (
    generate_graph,
    normalized_adjacency,
    spectral_kernels,
    tail_kernel_from_spectrum,
)
from validate_submission_comparators import method_pvalues


OUTPUT = output_dir("results_network_mismeasurement")
KINDS = ("ER", "SBM", "BA")
DELTAS = (0.3, 0.6)
PERTURBATIONS = (
    ("exact", 0.0),
    ("delete", 0.1),
    ("delete", 0.2),
    ("add", 0.1),
    ("add", 0.2),
    ("rewire", 0.1),
    ("rewire", 0.2),
)
METHODS = ("elc", "score", "one_hop", "adaptive")
LAMBDAS = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)
N = 240
GRAPH_REPLICATES = 20
ASSIGNMENTS_PER_GRAPH = 24
RANDOMIZATIONS = 399
PROBABILITY = 0.4


def perturb(graph: nx.Graph, mode: str, fraction: float, seed: int) -> nx.Graph:
    observed = graph.copy()
    if mode == "exact":
        return observed
    rng = np.random.default_rng(seed)
    edge_count = observed.number_of_edges()
    count = max(1, int(round(fraction * edge_count)))
    if mode == "delete":
        edges = list(observed.edges())
        chosen = rng.choice(len(edges), size=min(count, len(edges)), replace=False)
        observed.remove_edges_from([edges[int(index)] for index in chosen])
    elif mode == "add":
        nonedges = list(nx.non_edges(observed))
        chosen = rng.choice(len(nonedges), size=min(count, len(nonedges)), replace=False)
        observed.add_edges_from([nonedges[int(index)] for index in chosen])
    elif mode == "rewire":
        nx.double_edge_swap(
            observed,
            nswap=count,
            max_tries=max(100, 100 * count),
            seed=seed,
        )
    else:
        raise ValueError(mode)
    observed.remove_edges_from(nx.selfloop_edges(observed))
    return observed


def interval(values: np.ndarray) -> tuple[float, float]:
    mean = float(np.mean(values))
    critical = float(stats.t.ppf(0.975, len(values) - 1))
    half = critical * float(np.std(values, ddof=1) / math.sqrt(len(values)))
    return max(0.0, mean - half), min(1.0, mean + half)


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    graph_rng = np.random.default_rng(223607)
    simulation_rng = np.random.default_rng(244949)
    rows: list[dict[str, object]] = []

    for kind in KINDS:
        for graph_index in range(GRAPH_REPLICATES):
            graph_seed = int(graph_rng.integers(0, 2**31 - 1))
            true_graph = generate_graph(kind, N, graph_seed)
            true_normalized = normalized_adjacency(true_graph)
            eigenvalues, eigenvectors = np.linalg.eigh(true_normalized)
            split = np.random.default_rng(graph_seed + 104729).permutation(N)
            focal = np.sort(split[: N // 2])
            auxiliary = np.sort(split[N // 2 :])

            for delta in DELTAS:
                scenario_seed = int(simulation_rng.integers(0, 2**63 - 1))
                data_rng = np.random.default_rng(scenario_seed)
                treatment = data_rng.binomial(
                    1, PROBABILITY, size=(ASSIGNMENTS_PER_GRAPH, N)
                ).astype(float)
                errors = data_rng.normal(size=(ASSIGNMENTS_PER_GRAPH, N))
                causal_kernel = tail_kernel_from_spectrum(
                    eigenvalues, eigenvectors, delta
                )
                causal_kernel *= math.sqrt(N) / np.linalg.norm(
                    causal_kernel, ord="fro"
                )
                outcome = (
                    0.5 * treatment
                    + ((treatment - PROBABILITY) @ causal_kernel.T)
                    + errors
                )

                for perturbation_index, (mode, fraction) in enumerate(PERTURBATIONS):
                    observed_graph = perturb(
                        true_graph,
                        mode,
                        fraction,
                        graph_seed + 1_000_003 * (perturbation_index + 1),
                    )
                    adjacency = nx.to_numpy_array(observed_graph, dtype=float)
                    normalized = normalized_adjacency(observed_graph)
                    kernels, _, _ = spectral_kernels(normalized, LAMBDAS)
                    cross = kernels[:, focal][:, :, auxiliary].copy()
                    local = cross[0]
                    local_energy = float(np.sum(local**2))
                    for index in range(1, len(cross)):
                        cross[index] -= (
                            float(np.sum(cross[index] * local))
                            / max(local_energy, 1e-14)
                        ) * local
                    # The oracle argument is not reported here; using the observed
                    # delta-matched kernel keeps all calculations well defined.
                    observed_eigvals, observed_eigvecs = np.linalg.eigh(normalized)
                    oracle = tail_kernel_from_spectrum(
                        observed_eigvals, observed_eigvecs, delta
                    )[np.ix_(focal, auxiliary)]
                    oracle -= (
                        float(np.sum(oracle * local)) / max(local_energy, 1e-14)
                    ) * local
                    pvalues = method_pvalues(
                        outcome[:, focal],
                        treatment[:, focal],
                        treatment[:, auxiliary],
                        cross,
                        oracle,
                        adjacency[np.ix_(focal, focal)],
                        adjacency[np.ix_(focal, auxiliary)],
                        adjacency[focal].sum(axis=1),
                        PROBABILITY,
                        RANDOMIZATIONS,
                        np.random.default_rng(scenario_seed + 99991),
                    )
                    for method in METHODS:
                        rows.append(
                            {
                                "graph": kind,
                                "graph_index": graph_index,
                                "graph_seed": graph_seed,
                                "delta": delta,
                                "perturbation": mode,
                                "fraction": fraction,
                                "observed_edges": observed_graph.number_of_edges(),
                                "method": method,
                                "rejection_rate": float(
                                    np.mean(pvalues[method] <= 0.05)
                                ),
                                "datasets": ASSIGNMENTS_PER_GRAPH,
                            }
                        )

    with (OUTPUT / "graph_level_rates.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    summary: list[dict[str, object]] = []
    for kind in KINDS:
        for delta in DELTAS:
            for mode, fraction in PERTURBATIONS:
                for method in METHODS:
                    values = np.asarray(
                        [
                            row["rejection_rate"]
                            for row in rows
                            if row["graph"] == kind
                            and row["delta"] == delta
                            and row["perturbation"] == mode
                            and row["fraction"] == fraction
                            and row["method"] == method
                        ],
                        dtype=float,
                    )
                    low, high = interval(values)
                    summary.append(
                        {
                            "graph": kind,
                            "delta": delta,
                            "perturbation": mode,
                            "fraction": fraction,
                            "method": method,
                            "power": float(np.mean(values)),
                            "cluster_ci_low": low,
                            "cluster_ci_high": high,
                            "graph_replicates": GRAPH_REPLICATES,
                            "datasets": GRAPH_REPLICATES * ASSIGNMENTS_PER_GRAPH,
                        }
                    )
    with (OUTPUT / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    with (OUTPUT / "config.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "n": N,
                "graph_replicates": GRAPH_REPLICATES,
                "assignments_per_graph": ASSIGNMENTS_PER_GRAPH,
                "randomizations": RANDOMIZATIONS,
                "perturbations": PERTURBATIONS,
                "elapsed_seconds": time.perf_counter() - started,
            },
            handle,
            indent=2,
        )
    print(f"rows={len(summary)} elapsed={time.perf_counter() - started:.2f}s")


if __name__ == "__main__":
    main()
