#!/usr/bin/env python3
"""Design-exact wristband analysis in the Paluck school experiment.

The original experiment randomized eligible seed students within school-level
student blocks.  We condition on treated schools and use non-eligible students
as focal units, so their outcomes are imputable under the no-interference null.
Every randomization preserves the observed treated count in each school x
student block.
"""

from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from archive_paths import EXTERNAL_DATA, output_dir

import networkx as nx
import numpy as np
import pandas as pd
import pyreadr


LAMBDAS = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)


def args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data",
        type=Path,
        default=EXTERNAL_DATA,
    )
    parser.add_argument("--randomizations", type=int, default=49_999)
    parser.add_argument("--seed", type=int, default=20260831)
    parser.add_argument(
        "--output", type=Path, default=output_dir("results_paluck_primary_50k")
    )
    return parser.parse_args()


def normalized_adjacency(adjacency: np.ndarray) -> np.ndarray:
    degree = adjacency.sum(axis=1)
    inv_sqrt = np.zeros_like(degree)
    positive = degree > 0
    inv_sqrt[positive] = degree[positive] ** -0.5
    return inv_sqrt[:, None] * adjacency * inv_sqrt[None, :]


def kernel_family(normalized: np.ndarray) -> np.ndarray:
    eigenvalues, eigenvectors = np.linalg.eigh(normalized)
    kernels = []
    for parameter in LAMBDAS:
        if parameter == 0.0:
            weights = eigenvalues
        else:
            weights = eigenvalues / (1.0 - parameter * eigenvalues) - eigenvalues
        kernel = (eigenvectors * weights[None, :]) @ eigenvectors.T
        np.fill_diagonal(kernel, 0.0)
        kernels.append(kernel)
    return np.asarray(kernels)


def valid_numeric(values: np.ndarray) -> np.ndarray:
    return np.isfinite(values) & (values >= 0)


def decode_numeric(series: pd.Series) -> pd.Series:
    """Decode ICPSR factors such as '(01) Treatment' to their raw codes."""
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_numeric(series, errors="coerce")
    extracted = series.astype("string").str.extract(r"(-?\d+(?:\.\d+)?)", expand=False)
    return pd.to_numeric(extracted, errors="coerce")


def build_school(
    school_frame,
    outcome_name: str,
    outcome_sign: float,
) -> dict | None:
    ids = school_frame["ID"].to_numpy(dtype=float)
    # Roster IDs and all valid ST nominations start at 1.  ID 999 is the
    # release's non-roster placeholder and is not a network node.
    valid_id = np.isfinite(ids) & (ids > 0) & (ids != 999)
    school_frame = school_frame.loc[valid_id].copy()
    if school_frame["ID"].duplicated(keep=False).any():
        keep_indices = []
        for _, group in school_frame.groupby("ID", sort=False):
            if len(group) == 1:
                keep_indices.append(group.index[0])
                continue
            randomized_rows = group.loc[group["TREAT"].notna() & group["STRB"].notna()]
            if len(randomized_rows) != 1:
                school_id = int(group.iloc[0]["SCHID"])
                raise ValueError(
                    f"ambiguous duplicate roster ID in school {school_id}: "
                    f"ID={int(group.iloc[0]['ID'])}"
                )
            keep_indices.append(randomized_rows.index[0])
        school_frame = school_frame.loc[keep_indices].copy()
    ids = school_frame["ID"].to_numpy(dtype=int)
    # After the documented release-code cleanup, rows must be unique.
    if len(np.unique(ids)) != len(ids):
        values, counts = np.unique(ids, return_counts=True)
        duplicates = values[counts > 1]
        school_id = int(school_frame.iloc[0]["SCHID"])
        raise ValueError(
            f"duplicate within-school student ID: school={school_id}, "
            f"ids={duplicates[:20].tolist()}, total_duplicate_ids={len(duplicates)}"
        )
    id_to_index = {student_id: index for index, student_id in enumerate(ids)}
    n = len(ids)
    adjacency = np.zeros((n, n), dtype=float)
    for source, (_, row) in enumerate(school_frame.iterrows()):
        for column in (f"ST{i}" for i in range(1, 11)):
            target_value = row[column]
            if not np.isfinite(target_value) or target_value < 0:
                continue
            target = id_to_index.get(int(target_value))
            if target is not None and target != source:
                adjacency[source, target] = 1.0
                adjacency[target, source] = 1.0

    treatment_code = school_frame["TREAT"].to_numpy(dtype=float)
    strata = school_frame["STRB"].to_numpy(dtype=float)
    raw_outcome = school_frame[outcome_name].to_numpy(dtype=float)
    outcome = raw_outcome * outcome_sign
    # Treatment eligibility is fixed before assignment and outcomes.  Defining
    # F by eligibility alone is required by the conditional randomization
    # theorem; complete-case filtering on a follow-up outcome is not allowed.
    focal = np.flatnonzero(treatment_code == 0)
    auxiliary = np.flatnonzero(
        np.isin(treatment_code, (1, 2)) & np.isfinite(strata) & (strata > 0)
    )
    if len(focal) == 0 or len(auxiliary) == 0:
        return None
    if not np.all(valid_numeric(raw_outcome[focal])):
        school_id = int(school_frame.iloc[0]["SCHID"])
        missing = int(np.sum(~valid_numeric(raw_outcome[focal])))
        raise ValueError(
            f"outcome is incomplete for the outcome-free focal set: "
            f"school={school_id}, outcome={outcome_name}, invalid={missing}"
        )
    observed = (treatment_code[auxiliary] == 1).astype(float)
    normalized = normalized_adjacency(adjacency)
    kernels = kernel_family(normalized)[:, focal][:, :, auxiliary].copy()
    local_cross = kernels[0]
    local_energy = float(np.sum(local_cross**2))
    for kernel_index in range(1, len(kernels)):
        projection = float(np.sum(kernels[kernel_index] * local_cross)) / max(
            local_energy, 1e-14
        )
        kernels[kernel_index] -= projection * local_cross
    raw_cross = adjacency[np.ix_(focal, auxiliary)]
    y_focal = outcome[focal]
    weights = np.einsum("f,lfa->al", y_focal, kernels, optimize=True)
    athey_weights = y_focal @ raw_cross
    athey_counts = raw_cross.sum(axis=0)

    block_labels = [
        (int(school_frame.iloc[index]["SCHID"]), int(strata[index]))
        for index in auxiliary
    ]
    return {
        "nodes": n,
        "edges": int(adjacency.sum() // 2),
        "focal": len(focal),
        "auxiliary": len(auxiliary),
        "observed": observed,
        "weights": weights,
        "athey_weights": athey_weights,
        "athey_counts": athey_counts,
        "block_labels": block_labels,
    }


def randomization_matrix(
    observed: np.ndarray,
    block_labels: list[tuple[int, int]],
    randomizations: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray]:
    assignments = np.empty((randomizations + 1, len(observed)), dtype=np.uint8)
    assignments[0] = observed.astype(np.uint8)
    unique_blocks = sorted(set(block_labels))
    block_probabilities = np.empty(len(observed), dtype=float)
    for label in unique_blocks:
        indices = np.asarray(
            [index for index, value in enumerate(block_labels) if value == label],
            dtype=int,
        )
        values = observed[indices].astype(np.uint8)
        block_probabilities[indices] = float(np.mean(values))
        for draw in range(1, randomizations + 1):
            assignments[draw, indices] = rng.permutation(values)
    return assignments, block_probabilities


def randomization_pvalue(statistics: np.ndarray) -> float:
    return float(np.mean(statistics >= statistics[0] - 1e-12))


def standardize_scores(scores: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Studentize symmetrically and mark zero-variance columns as omitted."""
    score_mean = scores.mean(axis=0)
    score_sd = scores.std(axis=0, ddof=1)
    valid_components = score_sd > 1e-14
    if not np.any(valid_components):
        raise ValueError("all kernel components have zero conditional variance")
    z_scores = np.full(scores.shape, np.nan, dtype=float)
    z_scores[:, valid_components] = (
        scores[:, valid_components] - score_mean[None, valid_components]
    ) / score_sd[None, valid_components]
    return z_scores, valid_components


def analyze_outcome(
    frame,
    outcome_name: str,
    outcome_sign: float,
    randomizations: int,
    seed: int,
) -> dict:
    treated = frame.loc[frame["SCHTREAT"] == 1].copy()
    pieces = []
    for school_id in sorted(treated["SCHID"].dropna().unique()):
        piece = build_school(
            treated.loc[treated["SCHID"] == school_id], outcome_name, outcome_sign
        )
        if piece is not None:
            pieces.append(piece)
    observed = np.concatenate([piece["observed"] for piece in pieces])
    weights = np.concatenate([piece["weights"] for piece in pieces], axis=0)
    athey_weights = np.concatenate([piece["athey_weights"] for piece in pieces])
    athey_counts = np.concatenate([piece["athey_counts"] for piece in pieces])
    block_labels = [label for piece in pieces for label in piece["block_labels"]]

    rng = np.random.default_rng(seed)
    assignments, probabilities = randomization_matrix(
        observed, block_labels, randomizations, rng
    )
    centered = assignments.astype(float) - probabilities[None, :]
    scores = centered @ weights
    # Symmetric studentization across the observed assignment and all random
    # assignments retains exchangeability of the rank statistic.
    z_scores, valid_components = standardize_scores(scores)
    one_hop = z_scores[:, 0]
    if not valid_components[0]:
        raise ValueError("the one-hop component has zero conditional variance")
    adaptive = np.max(z_scores[:, valid_components], axis=1)
    adaptive_two_sided = np.max(np.abs(z_scores[:, valid_components]), axis=1)

    treated_num = assignments @ athey_weights
    treated_den = assignments @ athey_counts
    complement = 1 - assignments
    control_num = complement @ athey_weights
    control_den = complement @ athey_counts
    athey = treated_num / np.maximum(treated_den, 1e-14) - control_num / np.maximum(
        control_den, 1e-14
    )
    athey_sd = float(athey.std(ddof=1))
    if athey_sd <= 1e-14:
        raise ValueError("ELC has zero conditional variance")
    athey_z = (athey - athey.mean()) / athey_sd
    selected_index = int(np.nanargmax(z_scores[0]))
    selected_abs_index = int(np.nanargmax(np.abs(z_scores[0])))
    return {
        "outcome": outcome_name,
        "sign": outcome_sign,
        "schools": len(pieces),
        "nodes": int(sum(piece["nodes"] for piece in pieces)),
        "edges": int(sum(piece["edges"] for piece in pieces)),
        "focal_units": int(sum(piece["focal"] for piece in pieces)),
        "randomized_auxiliary_units": len(observed),
        "treated_auxiliary_units": int(observed.sum()),
        "randomization_blocks": len(set(block_labels)),
        "randomizations": randomizations,
        "p_elc_one_sided": randomization_pvalue(athey),
        "p_elc_two_sided": randomization_pvalue(np.abs(athey_z)),
        "p_one_hop_one_sided": randomization_pvalue(one_hop),
        "p_one_hop_two_sided": randomization_pvalue(np.abs(one_hop)),
        "p_adaptive_one_sided": randomization_pvalue(adaptive),
        "p_adaptive_two_sided": randomization_pvalue(adaptive_two_sided),
        "observed_athey": float(athey[0]),
        "observed_one_hop_z": float(one_hop[0]),
        "observed_adaptive_max_z": float(adaptive[0]),
        "observed_adaptive_two_sided_max_z": float(adaptive_two_sided[0]),
        "selected_lambda_one_sided": float(LAMBDAS[selected_index]),
        "selected_lambda_two_sided": float(LAMBDAS[selected_abs_index]),
        "valid_components": [
            float(parameter)
            for parameter, valid in zip(LAMBDAS, valid_components)
            if valid
        ],
        "component_z": {
            str(parameter): float(value)
            for parameter, value in zip(LAMBDAS, z_scores[0])
        },
    }


def main() -> None:
    options = args()
    options.output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    needed = [
        "SCHTREAT",
        "TREAT",
        "STRB",
        "SCHID",
        "ID",
        "WRISTOW2",
        *[f"ST{i}" for i in range(1, 11)],
    ]
    decoded_cache = options.output / "decoded_needed.pkl"
    if decoded_cache.exists():
        frame = pd.read_pickle(decoded_cache)
        print(f"loaded_current_dialogue_cache={decoded_cache}")
    else:
        result = pyreadr.read_r(str(options.data))
        frame = next(iter(result.values()))
        frame = frame[needed].copy()
        for column in needed:
            frame[column] = decode_numeric(frame[column])
        frame.to_pickle(decoded_cache)
        print(f"wrote_current_dialogue_cache={decoded_cache}")
    treated_school_count = frame.loc[frame["SCHTREAT"] == 1, "SCHID"].nunique()
    if treated_school_count < 20:
        raise ValueError(
            f"decoded only {treated_school_count} treated schools; factor decoding failed"
        )
    print(f"decoded_treated_schools={treated_school_count}")
    output = analyze_outcome(
        frame, "WRISTOW2", 1.0, options.randomizations, options.seed
    )
    print(json.dumps(output, indent=2))
    payload = {
        "source": "Paluck, Shepherd, and Aronow; ICPSR 37070 v2",
        "design": "within-school, within-student-block rerandomization",
        "focal_rule": "all non-eligible students; outcome-free and complete for WRISTOW2",
        "primary_inference": "two-sided maximum over seven kernel components",
        "seed": options.seed,
        "lambda_grid": list(LAMBDAS),
        "result": output,
        "elapsed_seconds": time.perf_counter() - started,
    }
    with (options.output / "primary_results.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(f"elapsed_seconds={payload['elapsed_seconds']:.2f}")


if __name__ == "__main__":
    main()
