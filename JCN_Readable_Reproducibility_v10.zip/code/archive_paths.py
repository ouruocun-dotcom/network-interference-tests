from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
RERUN_RESULTS = ROOT / 'results'
LOCKED_RESULTS = RERUN_RESULTS
FIGURES = ROOT / 'figures'
EXTERNAL_DATA = ROOT / 'external_data.rda'
def output_dir(name):
    return RERUN_RESULTS / name
