"""Common-draw field audit, exact block moments, and roster accounting.

Invoked by original_engine.py field --data authorized_ICPSR_file.rda.
No decoded input is redistributed. These are exploratory nominal p-values.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import pyreadr
from scipy.stats import beta
from archive_paths import output_dir
from empirical_paluck_test import (build_school,decode_numeric,randomization_matrix,LAMBDAS)
from empirical_paluck_direction_sensitivity import clean_school,combine as directions
from empirical_paluck_focal_sensitivity import combine as focals

def binomial_interval(exceed,b):
    lo = 0 if exceed==0 else beta.ppf(.025,exceed,b-exceed+1)
    hi = 1 if exceed==b else beta.ppf(.975,exceed+1,b-exceed)
    return lo,hi

def exact_sd(weights,blocks,observed):
    variance = np.zeros(weights.shape[1])
    for label in sorted(set(blocks)):
        ix = np.array([i for i,l in enumerate(blocks) if l==label])
        n=len(ix);m=observed[ix].sum()
        if n>1:
            centered = weights[ix]-weights[ix].mean(axis=0)
            variance += m*(n-m)/(n*(n-1))*np.sum(centered**2,axis=0)
    return np.sqrt(variance)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,required=True)
    opts=parser.parse_args()
    frame = next(iter(pyreadr.read_r(str(opts.data)).values()))
    needed=['SCHTREAT','TREAT','STRB','SCHID','ID','WRISTOW2',*[f'ST{i}' for i in range(1,11)]]
    frame=frame[needed].copy()
    for col in needed: frame[col]=decode_numeric(frame[col])
    treated=frame[frame.SCHTREAT==1]
    counts=[];pieces=[]
    for school_id in sorted(treated.SCHID.dropna().unique()):
        original=treated[treated.SCHID==school_id].copy()
        clean=clean_school(original)
        # Nullable pandas booleans must not drop unknown-treatment roster nodes.
        f=(clean.TREAT==0).fillna(False)
        c=(clean.TREAT.isin([1,2])&clean.STRB.notna()&(clean.STRB>0)).fillna(False)
        other=~(f|c)
        assert int(f.sum()+c.sum()+other.sum())==len(clean)
        counts.append({'school':school_id,'raw_rows':len(original),'nodes':len(clean),
                       'focal':int(f.sum()),'auxiliary':int(c.sum()),'other':int(other.sum()),
                       'other_TREAT_missing':int(clean.loc[other,'TREAT'].isna().sum()),
                       'other_STRB_missing':int(clean.loc[other,'STRB'].isna().sum())})
        pieces.append(build_school(original,'WRISTOW2',1.0))
    reference={'weights':np.concatenate([p['weights'] for p in pieces]),
               'observed':np.concatenate([p['observed'] for p in pieces]),
               'edge_weights':np.concatenate([p['athey_weights'] for p in pieces]),
               'edge_counts':np.concatenate([p['athey_counts'] for p in pieces]),
               'blocks':[l for p in pieces for l in p['block_labels']]}
    analyses={}
    for mode in ('undirected','undirected_row','nominator_to_nominee','nominee_to_nominator'):
        analysis=directions(frame,mode)
        assert analysis['block_labels']==reference['blocks']
        assert np.array_equal(analysis['observed'],reference['observed'])
        analyses['direction_'+mode]=analysis
    for rule in ('all_ineligible','within_one_hop','within_two_hops'):
        analysis=focals(frame,rule)
        assert analysis['blocks']==reference['blocks']
        assert np.array_equal(analysis['observed'],reference['observed'])
        analyses['focal_'+rule]=analysis
    assert np.allclose(analyses['direction_undirected']['weights'],reference['weights'])
    assert np.allclose(analyses['focal_all_ineligible']['weights'],reference['weights'])
    b=49999;seed=20260831
    assignments,probabilities=randomization_matrix(reference['observed'],reference['blocks'],b,
                                                     np.random.default_rng(seed))
    centered=assignments.astype(float)-probabilities[None,:]
    analyses={'primary':reference,**analyses}
    rows=[]
    for name,analysis in analyses.items():
        weights=analysis['weights']
        sd=exact_sd(weights,reference['blocks'],reference['observed'])
        z=np.divide(centered@weights,sd[None,:],out=np.zeros((b+1,len(sd))),where=sd[None,:]>1e-14)
        for direction,values in [('positive',z),('two_sided',np.abs(z))]:
            for method,t in [('onehop',values[:,0]),('adaptive',values.max(axis=1))]:
                e=int(np.sum(t[1:]>=t[0]-1e-12))
                lo,hi=binomial_interval(e,b)
                rows.append({'analysis':name,'direction':direction,'method':method,
                             'pvalue':(1+e)/(b+1),'exceedances':e,'B':b,'seed':seed,
                             'MC_tail_ci_low':lo,'MC_tail_ci_high':hi,
                             'observed_statistic':t[0],'selected_lambda':LAMBDAS[int(np.argmax(values[0]))],
                             'standardization':'exact block moments'})
        if name=='primary':
            treated_sum=assignments@reference['edge_weights']
            treated_count=assignments@reference['edge_counts']
            control_sum=(1-assignments)@reference['edge_weights']
            control_count=(1-assignments)@reference['edge_counts']
            assert np.all(treated_count>0) and np.all(control_count>0)
            elc=treated_sum/treated_count-control_sum/control_count
            for direction,t in [('positive',elc),('two_sided',np.abs(elc))]:
                e=int(np.sum(t[1:]>=t[0]-1e-12));lo,hi=binomial_interval(e,b)
                rows.append({'analysis':'primary','direction':direction,'method':'ELC',
                             'pvalue':(1+e)/(b+1),'exceedances':e,'B':b,'seed':seed,
                             'MC_tail_ci_low':lo,'MC_tail_ci_high':hi,
                             'observed_statistic':elc[0],
                             'standardization':'raw absolute contrast for two-sided test'})
            corr=np.corrcoef(z,rowvar=False)
            for i in range(7):
                for j in range(7):
                    rows.append({'analysis':'component_correlation','component_i':i,'component_j':j,
                                 'correlation':corr[i,j],'effective_rank':49/np.sum(corr*corr),
                                 'observed_component_z':z[0,i]})
    output=output_dir('revision_field')
    output.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(output/'field_common_draws.csv',index=False)
    pd.DataFrame(counts).to_csv(output/'field_roster_counts.csv',index=False)
    print(pd.DataFrame(counts).sum(numeric_only=True).to_string(),flush=True)
    print(pd.DataFrame(rows).query("method == 'adaptive' and direction == 'two_sided'").to_string(index=False),flush=True)

if __name__=='__main__':main()
