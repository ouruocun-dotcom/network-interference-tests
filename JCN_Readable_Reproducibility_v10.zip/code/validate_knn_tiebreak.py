#!/usr/bin/env python3
"""KNN statistic on the locked comparator design; no new outcome simulations.

Source: Alzubaidi and Higgins (2024), JCI 12, 20230029, Sections 3.2 and 7.
Ranks use shortest-path distance and an outcome-free fixed random priority.
The published statistic is evaluated on our common focal split; both the
published absolute-statistic test and the positive-direction version are saved.
Every original one-hop and matched-tail p-value is replayed and checked.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
import time
from pathlib import Path
from archive_paths import output_dir

import networkx as nx
import numpy as np
import pandas as pd

from validate_submission_comparators import Config, cluster_interval, upper_p
from validate_diffusion_kernel_test import generate_graph, normalized_adjacency, tail_kernel_from_spectrum

HERE = Path(__file__).resolve().parents[1]
LOCKED = HERE / "results" / "results_submission_comparators"
OUTPUT = output_dir("results_knn_tiebreak")
KS = (3, 10)
TIE_SEED_OFFSET = 15485863


def ordered_neighbors(graph: nx.Graph, focal: np.ndarray, k: int, seed: int) -> np.ndarray:
    n = graph.number_of_nodes()
    order = np.random.default_rng(seed).permutation(n)
    priority = np.empty(n, dtype=int)
    priority[order] = np.arange(n)
    rows = []
    for node in focal:
        distance = nx.single_source_shortest_path_length(graph, int(node))
        candidates = [j for j in distance if j != node]
        if len(candidates) < k:
            raise ValueError("fewer than K reachable neighbors")
        rows.append(sorted(candidates, key=lambda j: (distance[j], priority[j]))[:k])
    return np.asarray(rows, dtype=int)


def knn_statistics(y: np.ndarray, fixed: np.ndarray, assignments: np.ndarray,
                   neighbors: np.ndarray) -> tuple[np.ndarray, int]:
    """Cumulative T_K for all ranks; arrays: R x F, R x F, R x (B+1) x n."""
    reps, draws, _ = assignments.shape
    total = np.zeros((reps, draws))
    cumulative = []
    empty = 0
    for rank in range(neighbors.shape[1]):
        exposure = assignments[:, :, neighbors[:, rank]].astype(float)
        for own in (0, 1):
            mask = (fixed == own).astype(float)
            size = mask.sum(axis=1)
            count_t = np.einsum("rbf,rf->rb", exposure, mask)
            sum_t = np.einsum("rbf,rf->rb", exposure, mask * y)
            count_c = size[:, None] - count_t
            sum_c = (mask * y).sum(axis=1)[:, None] - sum_t
            valid = (count_t > 0) & (count_c > 0)
            empty += int(np.sum((size[:, None] > 0) & ~valid))
            diff = np.zeros_like(total)
            np.divide(sum_t, count_t, out=diff, where=valid)
            other = np.zeros_like(total)
            np.divide(sum_c, count_c, out=other, where=valid)
            # Symmetric extension for an empty exposure cell: zero contribution.
            total += (size / y.shape[1])[:, None] * (diff - other)
        cumulative.append(total.copy())
    return np.stack(cumulative, axis=-1), empty


def scalar_knn(y: np.ndarray, fixed: np.ndarray, assignment: np.ndarray,
               neighbors: np.ndarray) -> np.ndarray:
    total = 0.0
    values = []
    for rank in range(neighbors.shape[1]):
        for own in (0, 1):
            group = fixed == own
            exposed = assignment[neighbors[:, rank]] == 1
            if np.any(group & exposed) and np.any(group & ~exposed):
                total += group.mean() * (y[group & exposed].mean() - y[group & ~exposed].mean())
        values.append(total)
    return np.asarray(values)


def self_test() -> None:
    rng = np.random.default_rng(51023)
    y = rng.normal(size=(2, 4))
    fixed = np.array([[0, 1, 0, 1], [1, 0, 1, 0]])
    neighbors = np.array([[1, 4, 5], [0, 5, 4], [3, 4, 0], [2, 5, 1]])
    assignments = rng.binomial(1, .4, size=(2, 21, 6))
    assignments[:, :, :4] = fixed[:, None, :]
    vector, _ = knn_statistics(y, fixed, assignments, neighbors)
    direct = np.array([[scalar_knn(y[r], fixed[r], a, neighbors) for a in assignments[r]] for r in range(2)])
    assert np.allclose(vector, direct, atol=2e-14)
    # Exhaustive Bernoulli null check on a tiny conditional design.
    aux = np.array(list(itertools.product((0, 1), repeat=4)), dtype=int)
    full = np.zeros((1, len(aux), 8), dtype=int)
    full[:, :, :4] = fixed[0]
    full[0, :, 4:] = aux
    near = np.tile(np.arange(4, 8), (4, 1))
    vals, _ = knn_statistics(y[:1], fixed[:1], full, near)
    probs = .4 ** aux.sum(axis=1) * .6 ** (4 - aux.sum(axis=1))
    for k in (1, 3, 4):
        for absolute in (False, True):
            stat = np.abs(vals[0, :, k-1]) if absolute else vals[0, :, k-1]
            p = np.array([probs[stat >= s - 1e-12].sum() for s in stat])
            for alpha in np.linspace(0, 1, 101):
                assert probs[p <= alpha + 1e-14].sum() <= alpha + 1e-12
    print("PASS: vectorized KNN matches scalar formula; exhaustive tiny null valid", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test-only", action="store_true")
    opts = parser.parse_args()
    self_test()
    if opts.self_test_only:
        return
    start = time.perf_counter()
    cfg = Config()
    locked = pd.read_csv(LOCKED / "replicate_results.csv")
    configs = locked[["graph", "graph_index", "graph_seed", "delta", "scenario_seed"]].drop_duplicates()
    rows, diagnostics = [], []
    empty_cells = 0
    matched = 0
    for (kind, gi, gs), scenarios in configs.groupby(["graph", "graph_index", "graph_seed"], sort=False):
        gs = int(gs)
        graph = generate_graph(kind, cfg.n, gs)
        normalized = normalized_adjacency(graph)
        eigenvalues, eigenvectors = np.linalg.eigh(normalized)
        split = np.random.default_rng(gs + 104729).permutation(cfg.n)
        focal, auxiliary = np.sort(split[:cfg.n//2]), np.sort(split[cfg.n//2:])
        # Match the eigen-reconstructed one-hop block used by the locked code.
        local_full = (eigenvectors * eigenvalues[None, :]) @ eigenvectors.T
        np.fill_diagonal(local_full, 0)
        local = local_full[np.ix_(focal, auxiliary)]
        energy = np.sum(local**2)
        neighbors = ordered_neighbors(graph, focal, max(KS), gs + TIE_SEED_OFFSET)
        for row in scenarios.itertuples(index=False):
            delta = float(row.delta)
            seed = int(row.scenario_seed)
            rng = np.random.default_rng(seed)
            treatment = rng.binomial(1, cfg.treatment_probability, size=(cfg.assignments_per_graph, cfg.n)).astype(float)
            error = rng.normal(0, cfg.noise_sd, size=treatment.shape)
            if delta:
                q = tail_kernel_from_spectrum(eigenvalues, eigenvectors, delta)
                causal = q * math.sqrt(cfg.n) / np.linalg.norm(q, "fro")
                qcross = q[np.ix_(focal, auxiliary)]
                projection = np.sum(qcross * local) / energy
                oracle = qcross - projection * local
                diagnostics.append({
                    "graph": kind, "graph_index": int(gi), "delta": delta,
                    "removed_signal_energy_fraction": float(projection**2 * energy / np.sum(qcross**2)),
                    "orthogonality_residual": float(abs(np.sum(oracle*local)) / (np.linalg.norm(oracle)*np.linalg.norm(local))),
                })
            else:
                causal = np.zeros_like(normalized)
                oracle = normalized[np.ix_(focal, auxiliary)]
            y = cfg.direct_effect * treatment + cfg.contagion_strength * ((treatment-cfg.treatment_probability) @ causal.T) + error
            random = rng.binomial(1, cfg.treatment_probability,
                                  size=(cfg.assignments_per_graph, cfg.randomizations, len(auxiliary))).astype(float)
            # Exact replay of the two locked reference statistics.
            for method, kernel in (("one_hop", local), ("oracle", oracle)):
                weight = y[:, focal] @ kernel
                sd = math.sqrt(cfg.treatment_probability*(1-cfg.treatment_probability))*np.linalg.norm(weight, axis=1)
                obs = np.sum((treatment[:, auxiliary]-cfg.treatment_probability)*weight, axis=1)/sd
                ref = np.einsum("rba,ra->rb", random-cfg.treatment_probability, weight)/sd[:, None]
                p = upper_p(obs, ref)
                old = locked[(locked.graph == kind) & (locked.graph_index == gi) & (locked.delta == delta) & (locked.method == method)].sort_values("replicate").pvalue.to_numpy()
                if not np.allclose(p, old, rtol=0, atol=1e-12):
                    raise AssertionError(f"reference replay differs: {kind} {gi} {delta} {method}")
                matched += len(p)
            full = np.broadcast_to(treatment[:, None, :], (len(treatment), cfg.randomizations+1, cfg.n)).astype(np.uint8).copy()
            full[:, 1:, auxiliary] = random.astype(np.uint8)
            stat, empty = knn_statistics(y[:, focal], treatment[:, focal], full, neighbors)
            empty_cells += empty
            for k in KS:
                for side in ("positive", "two_sided"):
                    values = stat[:, :, k-1]
                    if side == "two_sided":
                        values = abs(values)
                    ps = upper_p(values[:, 0], values[:, 1:])
                    for rep, p in enumerate(ps):
                        rows.append({"graph": kind, "graph_index": int(gi), "graph_seed": gs,
                                     "delta": delta, "scenario_seed": seed, "replicate": rep,
                                     "k": k, "side": side, "pvalue": float(p)})
        if int(gi) % 5 == 4:
            print(f"{kind}: completed {int(gi)+1}/25 graphs", flush=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    data = pd.DataFrame(rows)
    data.to_csv(OUTPUT / "replicate_results.csv", index=False)
    diag = pd.DataFrame(diagnostics)
    diag.to_csv(OUTPUT / "matched_tail_audit.csv", index=False)
    summaries = []
    for (kind, delta, k, side), part in data.groupby(["graph", "delta", "k", "side"]):
        rates = part.assign(reject=part.pvalue <= .05).groupby("graph_index").reject.mean().to_numpy()
        lo, hi = cluster_interval(rates)
        summaries.append({"graph": kind, "delta": delta, "k": int(k), "side": side,
                          "power": float(rates.mean()), "ci_low": lo, "ci_high": hi, "datasets": len(part)})
    pd.DataFrame(summaries).to_csv(OUTPUT / "summary.csv", index=False)
    meta = {"source": "https://doi.org/10.1515/jci-2023-0029", "source_section": "7",
            "K": list(KS), "ranking": "shortest-path distance, fixed random vertex priority",
            "tie_seed": f"graph_seed + {TIE_SEED_OFFSET}", "focal_rule": "locked random half-split",
            "empty_exposure_cells": empty_cells, "reference_pvalues_reproduced": matched,
            "datasets_per_graph_delta": 800, "randomizations": cfg.randomizations,
            "self_tests": "scalar equivalence and exhaustive tiny Bernoulli null passed",
            "elapsed_seconds": time.perf_counter()-start}
    (OUTPUT / "run_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps(meta, indent=2), flush=True)
    print(pd.DataFrame(summaries).to_string(index=False), flush=True)

if __name__ == "__main__":
    main()
