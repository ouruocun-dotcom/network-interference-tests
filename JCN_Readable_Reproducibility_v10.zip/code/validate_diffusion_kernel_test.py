#!/usr/bin/env python3
"""Simulation validation for diffusion-kernel randomization tests.

This script is intentionally self-contained and was written for the current
topic search.  It compares a one-hop randomization test, an adaptive
diffusion-kernel test, and an oracle matched-kernel test under Bernoulli
randomization.  Calculations are batched by graph for speed and all seeds and
settings are recorded in machine-readable output.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from scipy import stats


@dataclass(frozen=True)
class Config:
    n: int
    graph_replicates: int
    assignments_per_graph: int
    randomizations: int
    treatment_probability: float
    direct_effect: float
    contagion_strength: float
    noise_sd: float
    graph_seed: int
    simulation_seed: int
    lambdas: tuple[float, ...]
    deltas: tuple[float, ...]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("pilot", "final"), default="pilot")
    parser.add_argument("--output", type=Path, default=Path("results_pilot"))
    parser.add_argument("--theta", type=float, default=2.0)
    parser.add_argument("--null-only", action="store_true")
    parser.add_argument("--simulation-seed", type=int)
    parser.add_argument("--graph-replicates", type=int)
    parser.add_argument("--assignments-per-graph", type=int)
    return parser.parse_args()


def make_config(mode: str, theta: float) -> Config:
    if mode == "pilot":
        return Config(
            n=160,
            graph_replicates=5,
            assignments_per_graph=20,
            randomizations=199,
            treatment_probability=0.4,
            direct_effect=0.5,
            contagion_strength=theta,
            noise_sd=1.0,
            graph_seed=90210,
            simulation_seed=271828,
            lambdas=(0.0, 0.25, 0.5, 0.7, 0.82, 0.9),
            deltas=(0.0, 0.3, 0.6, 0.85),
        )
    return Config(
        n=240,
        graph_replicates=25,
        assignments_per_graph=32,
        randomizations=499,
        treatment_probability=0.4,
        direct_effect=0.5,
        contagion_strength=theta,
        noise_sd=1.0,
        graph_seed=90210,
        simulation_seed=271828,
        lambdas=(0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92),
        deltas=(0.0, 0.3, 0.6, 0.85),
    )


def generate_graph(kind: str, n: int, seed: int) -> nx.Graph:
    if kind == "ER":
        graph = nx.fast_gnp_random_graph(n, 8.0 / (n - 1), seed=seed)
    elif kind == "SBM":
        n1 = n // 2
        graph = nx.stochastic_block_model(
            [n1, n - n1], [[0.06, 0.008], [0.008, 0.06]], seed=seed
        )
    elif kind == "BA":
        graph = nx.barabasi_albert_graph(n, 4, seed=seed)
    else:
        raise ValueError(kind)
    graph.remove_edges_from(nx.selfloop_edges(graph))
    return graph


def normalized_adjacency(graph: nx.Graph) -> np.ndarray:
    adjacency = nx.to_numpy_array(graph, dtype=float)
    degree = adjacency.sum(axis=1)
    inv_sqrt = np.zeros_like(degree)
    positive = degree > 0
    inv_sqrt[positive] = degree[positive] ** -0.5
    return inv_sqrt[:, None] * adjacency * inv_sqrt[None, :]


def spectral_kernels(
    normalized: np.ndarray, parameters: tuple[float, ...]
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    eigenvalues, eigenvectors = np.linalg.eigh(normalized)
    kernels = []
    for parameter in parameters:
        if parameter == 0.0:
            # The first component is the conventional one-hop score.
            weights = eigenvalues
        else:
            # Remove the one-hop component.  These components begin at W^2,
            # so the adaptive test can distinguish spillover from multihop
            # propagation instead of repeatedly testing near-duplicates of W.
            weights = (
                eigenvalues / (1.0 - parameter * eigenvalues) - eigenvalues
            )
        kernel = (eigenvectors * weights[None, :]) @ eigenvectors.T
        np.fill_diagonal(kernel, 0.0)
        kernels.append(kernel)
    return np.asarray(kernels), eigenvalues, eigenvectors


def kernel_from_spectrum(
    eigenvalues: np.ndarray, eigenvectors: np.ndarray, parameter: float
) -> np.ndarray:
    weights = eigenvalues / (1.0 - parameter * eigenvalues)
    kernel = (eigenvectors * weights[None, :]) @ eigenvectors.T
    np.fill_diagonal(kernel, 0.0)
    return kernel


def tail_kernel_from_spectrum(
    eigenvalues: np.ndarray, eigenvectors: np.ndarray, parameter: float
) -> np.ndarray:
    if parameter == 0.0:
        weights = eigenvalues
    else:
        weights = eigenvalues / (1.0 - parameter * eigenvalues) - eigenvalues
    kernel = (eigenvectors * weights[None, :]) @ eigenvectors.T
    np.fill_diagonal(kernel, 0.0)
    return kernel


def randomized_pvalues(
    y_focal: np.ndarray,
    x_auxiliary: np.ndarray,
    kernel_cross: np.ndarray,
    adjacency_cross: np.ndarray,
    probability: float,
    randomizations: int,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return Athey, one-hop, and adaptive randomization p-values."""
    batch, auxiliary_count = x_auxiliary.shape
    # v[r, a, l] is the assignment-score weight for auxiliary node a.
    weights = np.einsum("rf,lfa->ral", y_focal, kernel_cross, optimize=True)
    denominators = math.sqrt(probability * (1.0 - probability)) * np.linalg.norm(
        weights, axis=1
    )
    if np.any(denominators <= 1e-14):
        raise ValueError("zero-variance diffusion component in simulation")
    observed_centered = x_auxiliary - probability
    observed_z = np.einsum(
        "ra,ral->rl", observed_centered, weights, optimize=True
    ) / denominators

    randomized = rng.binomial(
        1,
        probability,
        size=(batch, randomizations, auxiliary_count),
    ).astype(float)
    randomized -= probability
    randomized_z = np.einsum(
        "rba,ral->rbl", randomized, weights, optimize=True
    ) / denominators[:, None, :]

    # Positive contagion is the scientifically prespecified direction.  A
    # one-sided score is exact under the null and avoids throwing away the
    # sign coherence created by a monotone causal cascade.
    observed_local = observed_z[:, 0]
    randomized_local = randomized_z[:, :, 0]
    observed_adaptive = np.max(observed_z, axis=1)
    randomized_adaptive = np.max(randomized_z, axis=2)

    # Published neighborhood-exposure comparator, following the statistic
    # U(X,Y)-U(1-X,Y) in Athey et al. (2018).
    outcome_edge_weights = y_focal @ adjacency_cross
    focal_edge_counts = adjacency_cross.sum(axis=0)

    def athey_stat(assignments: np.ndarray) -> np.ndarray:
        if assignments.ndim == 2:
            treated_num = np.sum(assignments * outcome_edge_weights, axis=1)
            treated_den = np.sum(assignments * focal_edge_counts, axis=1)
            control_num = np.sum((1.0 - assignments) * outcome_edge_weights, axis=1)
            control_den = np.sum((1.0 - assignments) * focal_edge_counts, axis=1)
        else:
            treated_num = np.einsum(
                "rba,ra->rb", assignments, outcome_edge_weights, optimize=True
            )
            treated_den = np.einsum(
                "rba,a->rb", assignments, focal_edge_counts, optimize=True
            )
            control_num = np.einsum(
                "rba,ra->rb", 1.0 - assignments, outcome_edge_weights, optimize=True
            )
            control_den = np.einsum(
                "rba,a->rb", 1.0 - assignments, focal_edge_counts, optimize=True
            )
        treated_den = np.maximum(treated_den, 1e-14)
        control_den = np.maximum(control_den, 1e-14)
        return treated_num / treated_den - control_num / control_den

    observed_athey = athey_stat(x_auxiliary)
    randomized_assignments = randomized + probability
    randomized_athey = athey_stat(randomized_assignments)
    athey_p = (1 + np.sum(randomized_athey >= observed_athey[:, None], axis=1)) / (
        randomizations + 1
    )
    local_p = (1 + np.sum(randomized_local >= observed_local[:, None], axis=1)) / (
        randomizations + 1
    )
    adaptive_p = (
        1
        + np.sum(randomized_adaptive >= observed_adaptive[:, None], axis=1)
    ) / (randomizations + 1)
    return athey_p, local_p, adaptive_p


def oracle_pvalues(
    y_focal: np.ndarray,
    x_auxiliary: np.ndarray,
    kernel_cross: np.ndarray,
    probability: float,
    randomizations: int,
    rng: np.random.Generator,
) -> np.ndarray:
    batch, auxiliary_count = x_auxiliary.shape
    weights = y_focal @ kernel_cross
    denominator = math.sqrt(probability * (1.0 - probability)) * np.linalg.norm(
        weights, axis=1
    )
    denominator = np.maximum(denominator, 1e-14)
    observed = np.sum((x_auxiliary - probability) * weights, axis=1) / denominator
    randomized = rng.binomial(
        1, probability, size=(batch, randomizations, auxiliary_count)
    ).astype(float)
    randomized -= probability
    randomized_statistic = (
        np.einsum("rba,ra->rb", randomized, weights, optimize=True)
        / denominator[:, None]
    )
    return (1 + np.sum(randomized_statistic >= observed[:, None], axis=1)) / (
        randomizations + 1
    )


def cluster_interval(values: np.ndarray, confidence: float = 0.95) -> tuple[float, float]:
    count = len(values)
    mean = float(np.mean(values))
    if count < 2:
        return mean, mean
    standard_error = float(np.std(values, ddof=1) / math.sqrt(count))
    critical = float(stats.t.ppf((1.0 + confidence) / 2.0, count - 1))
    return max(0.0, mean - critical * standard_error), min(1.0, mean + critical * standard_error)


def run(config: Config, output: Path) -> list[dict[str, float | int | str]]:
    output.mkdir(parents=True, exist_ok=True)
    graph_kinds = ("ER", "SBM", "BA")
    methods = ("athey", "one_hop", "adaptive", "oracle")
    alpha_levels = (0.01, 0.05, 0.10)
    records: list[dict[str, float | int | str]] = []
    graph_details: list[dict[str, float | int | str]] = []
    master_graph_rng = np.random.default_rng(config.graph_seed)
    master_sim_rng = np.random.default_rng(config.simulation_seed)

    for graph_kind in graph_kinds:
        for graph_index in range(config.graph_replicates):
            graph_seed = int(master_graph_rng.integers(0, 2**31 - 1))
            graph = generate_graph(graph_kind, config.n, graph_seed)
            normalized = normalized_adjacency(graph)
            grid_kernels, eigenvalues, eigenvectors = spectral_kernels(
                normalized, config.lambdas
            )
            split_rng = np.random.default_rng(graph_seed + 104729)
            permutation = split_rng.permutation(config.n)
            focal = np.sort(permutation[: config.n // 2])
            auxiliary = np.sort(permutation[config.n // 2 :])
            kernel_cross = grid_kernels[:, focal][:, :, auxiliary].copy()
            local_cross = kernel_cross[0]
            local_energy = float(np.sum(local_cross**2))
            for kernel_index in range(1, len(kernel_cross)):
                projection = float(np.sum(kernel_cross[kernel_index] * local_cross)) / max(
                    local_energy, 1e-14
                )
                kernel_cross[kernel_index] -= projection * local_cross
            adjacency = nx.to_numpy_array(graph, dtype=float)
            adjacency_cross = adjacency[np.ix_(focal, auxiliary)]
            graph_details.append(
                {
                    "graph": graph_kind,
                    "graph_index": graph_index,
                    "graph_seed": graph_seed,
                    "nodes": config.n,
                    "edges": graph.number_of_edges(),
                    "mean_degree": 2.0 * graph.number_of_edges() / config.n,
                    "isolates": nx.number_of_isolates(graph),
                    "spectral_radius": float(np.max(np.abs(eigenvalues))),
                }
            )

            for delta in config.deltas:
                scenario_seed = int(master_sim_rng.integers(0, 2**63 - 1))
                rng = np.random.default_rng(scenario_seed)
                reps = config.assignments_per_graph
                treatment = rng.binomial(
                    1, config.treatment_probability, size=(reps, config.n)
                ).astype(float)
                centered = treatment - config.treatment_probability
                errors = rng.normal(0.0, config.noise_sd, size=(reps, config.n))
                if delta == 0.0:
                    causal_kernel = np.zeros((config.n, config.n))
                else:
                    # A delayed causal cascade whose observed endpoint begins
                    # after two links: W^2(I-delta W)^(-1).  The tail kernel
                    # below is delta times this matrix, and the scalar cancels
                    # when we normalize the cross-unit effect energy.
                    causal_kernel = tail_kernel_from_spectrum(
                        eigenvalues, eigenvectors, delta
                    )
                    frobenius = np.linalg.norm(causal_kernel, ord="fro")
                    causal_kernel *= math.sqrt(config.n) / frobenius
                outcome = (
                    config.direct_effect * treatment
                    + config.contagion_strength * (centered @ causal_kernel.T)
                    + errors
                )
                y_focal = outcome[:, focal]
                x_auxiliary = treatment[:, auxiliary]

                athey_p, local_p, adaptive_p = randomized_pvalues(
                    y_focal,
                    x_auxiliary,
                    kernel_cross,
                    adjacency_cross,
                    config.treatment_probability,
                    config.randomizations,
                    rng,
                )
                oracle_kernel = tail_kernel_from_spectrum(
                    eigenvalues, eigenvectors, delta
                )[np.ix_(focal, auxiliary)]
                if delta > 0.0:
                    oracle_projection = float(np.sum(oracle_kernel * local_cross)) / max(
                        local_energy, 1e-14
                    )
                    oracle_kernel = oracle_kernel - oracle_projection * local_cross
                oracle_p = oracle_pvalues(
                    y_focal,
                    x_auxiliary,
                    oracle_kernel,
                    config.treatment_probability,
                    config.randomizations,
                    rng,
                )
                for method, pvalues in zip(
                    methods, (athey_p, local_p, adaptive_p, oracle_p)
                ):
                    for replicate, pvalue in enumerate(pvalues):
                        records.append(
                            {
                                "graph": graph_kind,
                                "graph_index": graph_index,
                                "graph_seed": graph_seed,
                                "delta": delta,
                                "method": method,
                                "replicate": replicate,
                                "scenario_seed": scenario_seed,
                                "pvalue": float(pvalue),
                            }
                        )

    with (output / "replicate_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    with (output / "graph_details.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(graph_details[0]))
        writer.writeheader()
        writer.writerows(graph_details)

    summaries: list[dict[str, float | int | str]] = []
    for graph_kind in graph_kinds:
        for delta in config.deltas:
            for method in methods:
                subset = [
                    row
                    for row in records
                    if row["graph"] == graph_kind
                    and row["delta"] == delta
                    and row["method"] == method
                ]
                pvalues = np.asarray([row["pvalue"] for row in subset], dtype=float)
                for alpha in alpha_levels:
                    by_graph = []
                    for graph_index in range(config.graph_replicates):
                        graph_p = np.asarray(
                            [
                                row["pvalue"]
                                for row in subset
                                if row["graph_index"] == graph_index
                            ],
                            dtype=float,
                        )
                        by_graph.append(float(np.mean(graph_p <= alpha)))
                    lower, upper = cluster_interval(np.asarray(by_graph))
                    summaries.append(
                        {
                            "graph": graph_kind,
                            "delta": delta,
                            "method": method,
                            "alpha": alpha,
                            "rejection_rate": float(np.mean(pvalues <= alpha)),
                            "cluster_ci_low": lower,
                            "cluster_ci_high": upper,
                            "replicates": len(pvalues),
                            "mean_pvalue": float(np.mean(pvalues)),
                        }
                    )
    with (output / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)

    with (output / "config.json").open("w", encoding="utf-8") as handle:
        json.dump(asdict(config), handle, indent=2)

    plot_power(summaries, config, output)
    return summaries


def plot_power(
    summaries: list[dict[str, float | int | str]], config: Config, output: Path
) -> None:
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.7), sharey=True)
    colors = {
        "athey": "#B279A2",
        "one_hop": "#4C78A8",
        "adaptive": "#E45756",
        "oracle": "#54A24B",
    }
    labels = {
        "athey": "Neighborhood exposure",
        "one_hop": "One-hop score",
        "adaptive": "Adaptive diffusion",
        "oracle": "Oracle",
    }
    for axis, graph_kind in zip(axes, ("ER", "SBM", "BA")):
        for method in ("athey", "one_hop", "adaptive", "oracle"):
            selected = [
                row
                for row in summaries
                if row["graph"] == graph_kind
                and row["method"] == method
                and row["alpha"] == 0.05
            ]
            selected.sort(key=lambda row: float(row["delta"]))
            axis.plot(
                [float(row["delta"]) for row in selected],
                [float(row["rejection_rate"]) for row in selected],
                marker="o",
                linewidth=2,
                color=colors[method],
                label=labels[method],
            )
        axis.axhline(0.05, color="black", linewidth=1, linestyle="--", alpha=0.5)
        axis.set_title(graph_kind)
        axis.set_xlabel("contagion depth $\\delta$")
        axis.set_ylim(0, 1)
        axis.grid(alpha=0.2)
    axes[0].set_ylabel("rejection probability at $\\alpha=0.05$")
    axes[-1].legend(frameon=False, loc="best")
    fig.suptitle(
        f"Diffusion-kernel causal-contagion test (n={config.n}, theta={config.contagion_strength:g})"
    )
    fig.tight_layout()
    fig.savefig(output / "power_curve.png", dpi=200)
    plt.close(fig)


def print_key_results(summaries: list[dict[str, float | int | str]]) -> None:
    print("graph delta method rejection_rate cluster_95pct_CI")
    for row in summaries:
        if row["alpha"] == 0.05:
            print(
                f"{row['graph']:>3} {float(row['delta']):.2f} "
                f"{row['method']:>8} {float(row['rejection_rate']):.3f} "
                f"[{float(row['cluster_ci_low']):.3f}, {float(row['cluster_ci_high']):.3f}]"
            )


def main() -> None:
    args = parse_args()
    config = make_config(args.mode, args.theta)
    replacements = {}
    if args.null_only:
        replacements["deltas"] = (0.0,)
    if args.simulation_seed is not None:
        replacements["simulation_seed"] = args.simulation_seed
    if args.graph_replicates is not None:
        replacements["graph_replicates"] = args.graph_replicates
    if args.assignments_per_graph is not None:
        replacements["assignments_per_graph"] = args.assignments_per_graph
    if replacements:
        config = replace(config, **replacements)
    start = time.perf_counter()
    summaries = run(config, args.output)
    print_key_results(summaries)
    print(f"elapsed_seconds={time.perf_counter() - start:.2f}")


if __name__ == "__main__":
    main()
