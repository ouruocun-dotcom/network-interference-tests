#!/usr/bin/env python3
"""Create grayscale-safe manuscript figures from the locked result files."""

from __future__ import annotations

import json
from pathlib import Path
from archive_paths import FIGURES

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUT = FIGURES
OUT.mkdir(parents=True, exist_ok=True)

METHODS = ["elc", "score", "one_hop", "adaptive", "oracle"]
LABELS = {
    "elc": "ELC",
    "score": "Score",
    "one_hop": "One-hop",
    "adaptive": "Adaptive",
    "oracle": "Matched tail",
}
STYLES = {
    "elc": ("o", "-", "0.65"),
    "score": ("s", "--", "0.5"),
    "one_hop": ("^", "-.", "0.35"),
    "adaptive": ("D", "-", "0.0"),
    "oracle": ("x", ":", "0.2"),
}


def setup() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "figure.dpi": 120,
        }
    )


def comparator_power() -> None:
    data = pd.read_csv(RESULTS / "results_submission_comparators" / "summary.csv")
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), sharey=True)
    for axis, graph in zip(axes, ["ER", "SBM", "BA"]):
        for method in METHODS:
            part = data[(data.graph == graph) & (data.method == method)].sort_values("delta")
            marker, line, color = STYLES[method]
            axis.plot(
                part.delta,
                part.rejection_rate,
                marker=marker,
                linestyle=line,
                color=color,
                linewidth=1.25,
                markersize=4,
                label=LABELS[method],
            )
        axis.axhline(0.05, color="0.75", linewidth=0.8)
        axis.set_title(graph)
        axis.set_xlabel(r"Cascade parameter $\delta$")
        axis.set_xticks([0, 0.3, 0.6, 0.85])
        axis.set_ylim(0, 0.6)
    axes[0].set_ylabel("Rejection probability")
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, ncol=5, loc="upper center", frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.86))
    fig.savefig(OUT / "comparator_power.png", dpi=400, bbox_inches="tight")
    plt.close(fig)


def power_surface() -> None:
    data = pd.read_csv(RESULTS / "results_power_surface" / "summary.csv")
    data = data.groupby(["n", "delta", "theta", "method"], as_index=False).power.mean()
    fig, axes = plt.subplots(1, 2, figsize=(6.4, 2.9), sharey=True)
    for axis, delta in zip(axes, [0.3, 0.6]):
        for method in ["one_hop", "adaptive"]:
            part = data[(data.delta == delta) & (data.method == method)]
            for theta, linestyle in zip([0.5, 1.0, 1.5], [":", "--", "-"]):
                line = part[part.theta == theta].sort_values("n")
                marker, _, color = STYLES[method]
                axis.plot(
                    line.n,
                    line.power,
                    marker=marker,
                    linestyle=linestyle,
                    color=color,
                    linewidth=1.1,
                    markersize=3.5,
                    label=f"{LABELS[method]}, $\\theta={theta:g}$",
                )
        axis.set_title(rf"$\delta={delta:g}$")
        axis.set_xlabel("Network size")
        axis.set_xticks([120, 240, 480])
        axis.set_ylim(0, 1)
    axes[0].set_ylabel("Power (graph-family average)")
    handles, labels = axes[1].get_legend_handles_labels()
    fig.legend(handles, labels, ncol=3, fontsize=7.2, loc="upper center", frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.83))
    fig.savefig(OUT / "power_surface.png", dpi=400, bbox_inches="tight")
    plt.close(fig)


def network_error() -> None:
    data = pd.read_csv(RESULTS / "results_network_mismeasurement" / "summary.csv")
    data = data[(data.method == "adaptive") & (data.delta == 0.3)]
    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.5), sharey=True)
    for axis, graph in zip(axes, ["ER", "SBM", "BA"]):
        part = data[data.graph == graph]
        exact = float(part[part.perturbation == "exact"].power.iloc[0])
        for perturbation, marker, linestyle, color in [
            ("delete", "o", "-", "0.15"),
            ("add", "s", "--", "0.4"),
            ("rewire", "^", "-.", "0.65"),
        ]:
            line = part[part.perturbation == perturbation].sort_values("fraction")
            axis.plot(
                np.r_[0, line.fraction],
                np.r_[exact, line.power],
                marker=marker,
                linestyle=linestyle,
                color=color,
                label=perturbation.capitalize(),
            )
        axis.set_title(graph)
        axis.set_xlabel("Edge perturbation proportion")
        axis.set_xticks([0, 0.1, 0.2])
        axis.set_ylim(0, 0.6)
    axes[0].set_ylabel("Adaptive-test power")
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, ncol=3, loc="upper center", frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.86))
    fig.savefig(OUT / "network_mismeasurement.png", dpi=400, bbox_inches="tight")
    plt.close(fig)


def empirical_components() -> None:
    with (RESULTS / "results_paluck_primary_50k" / "primary_results.json").open(
        encoding="utf-8"
    ) as handle:
        payload = json.load(handle)
    lambdas = payload["lambda_grid"]
    result = payload["result"]
    fig, axis = plt.subplots(figsize=(5.7, 3.0))
    component_z = [result["component_z"][str(value)] for value in lambdas]
    axis.plot(
        lambdas,
        component_z,
        marker="o",
        linestyle="-",
        color="0.0",
        linewidth=1.35,
    )
    axis.axhline(0, color="0.75", linewidth=0.8)
    axis.set_xlabel(r"Kernel parameter $\lambda$ ($0$ denotes one hop)")
    axis.set_ylabel("Observed standardized score")
    fig.tight_layout()
    fig.savefig(OUT / "paluck_component_scores.png", dpi=400, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    setup()
    comparator_power()
    power_surface()
    network_error()
    empirical_components()


if __name__ == "__main__":
    main()
