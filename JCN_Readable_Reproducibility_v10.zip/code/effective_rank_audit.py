"""Independent, small checks of the spectral extension; seed 2026101047.

No third-party data or supplied result files are required. Outputs one CSV.
This is not a rerun of the attachment's full network experiments.
"""
from pathlib import Path
import argparse
import csv
import itertools
import numpy as np
from scipy.stats import chi2, norm


def falling(a, d):
    result = 1
    for j in range(d):
        result *= a-j
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('effective_rank_audit.csv'))
    args = parser.parse_args()
    rng = np.random.default_rng(2026101047)
    rows = []
    def save(test, **kwargs):
        rows.append(dict(test=test, **kwargs))

    # Independently enumerate all assignments; derive coefficients from
    # coincidence-group sums, rather than copying the rational formulas.
    for m, k in [(7,3), (8,4), (9,2), (10,6), (7,1), (7,6)]:
        pi = np.eye(m)-np.ones((m,m))/m
        a = rng.normal(size=(m,m)); a = pi@((a+a.T)/2)@pi
        t, f, g = np.trace(a), np.sum(a*a), np.sum(np.diag(a)**2)
        mus = [None]+[falling(k,d)/falling(m,d) for d in range(1,5)]
        mu1,mu2,mu3,mu4 = mus[1:]
        kappa = k*(m-k)/(m*(m-1))
        mean = kappa*t
        second = mu1*g+mu2*(t*t+2*f-7*g)+mu3*(12*g-2*t*t-4*f)+mu4*(t*t+2*f-6*g)
        vals = []
        for subset in itertools.combinations(range(m),k):
            x = np.zeros(m); x[list(subset)] = 1
            vals.append(x@a@x)
        vals = np.asarray(vals)
        cf=2*k*(k-1)*(m-k)*(m-k-1)/falling(m,4)
        cg=k*(m-k)*(6*k*k-6*k*m+m*m+m)/falling(m,4)
        ct=-k*(m-k)*(m*(m-2*k)**2-2*m*m+6*k*m-6*k*k+m)/(m*m*(m-1)**2*(m-2)*(m-3))
        var = cf*f+cg*g+ct*t*t
        errors = [abs(vals.mean()-mean), abs(vals.var()-var), abs(second-mean*mean-var)]
        assert max(errors)<1e-10, (m,k,errors)
        save('srs_variance',m=m,k=k,mean_error=errors[0],variance_error=errors[1],expansion_error=errors[2])

    # Bernoulli(1/2), A=H'H=b I+(1-b) vv', v=1/sqrt(m), b=2/(m-1).
    # Full-rank examples with bounded effective rank and power tending to 1.
    for m in [64,256,1024]:
        reps, B, count = 1024,499,0
        b=2/(m-1)
        for start in range(0,reps,16):
            u=(rng.integers(0,2,size=(16,m))-.5)
            ref=(rng.integers(0,2,size=(16,B,m))-.5)
            w=b*u+(1-b)*u.mean(axis=1,keepdims=True)
            obs=np.abs(np.sum(w*u,axis=1))
            rnd=np.abs(np.einsum('rc,rbc->rb',w,ref))
            pv=(1+np.sum(rnd>=obs[:,None]-1e-12,axis=1))/(B+1)
            count+=np.sum(pv<=.05)
        save('bounded_effective_rank',m=m,replicates=reps,B=B,effective_rank=9/(1+4/(m-1)),rate=count/reps)

    # Exact rank-two normalized-score counterexample: H=I_2, p=1/2.
    us=np.asarray(list(itertools.product([-.5,.5],repeat=2)))
    cs=np.abs(us@us.T)/np.outer(np.linalg.norm(us,axis=1),np.linalg.norm(us,axis=1))
    pvs=np.mean(cs>=np.diag(cs)[:,None]-1e-12,axis=1)
    assert np.all(pvs==.5)
    save('rank_two_lattice',rank=2,rate=np.mean(pvs<=.05),minimum_p=pvs.min())

    # Diffuse equal-spectrum operators: independent Bernoulli block sums,
    # with growing block sizes. This tests the fixed-rank Gaussian formula.
    for rank in [1,2,4,8]:
        block=512; reps=4096; B=499; count=0
        for start in range(0,reps,64):
            z=(rng.binomial(block,.4,size=(64,B+1,rank))-.4*block)/np.sqrt(block*.24)
            obs=z[:,0,:]
            scores=np.abs(np.einsum('ri,rbi->rb',obs,z))
            pvs=(1+np.sum(scores[:,1:]>=scores[:,0,None]-1e-12,axis=1))/(B+1)
            count+=np.sum(pvs<=.05)
        save('equal_spectrum',rank=rank,replicates=reps,B=B,rate=count/reps,gaussian_prediction=chi2.sf(norm.ppf(.975)**2,rank))

    # Check supplied fast scores against independent direct evaluation and
    # the corrected scale-stable variant, including a zero kernel.
    from detectability import scores_fast, scores_safe
    for fixed in [False,True]:
        y=rng.normal(size=(8,9)); k=rng.normal(size=(3,9,12))
        X,mu=scores_fast.draws(rng,(8,40,12),fixed)
        safe=scores_safe.normalized(y,k,X,mu)
        legacy=scores_fast.normalized(y,k,X,mu,scores_fast.kx_norms(k,X,mu))
        error=np.max(np.abs(safe-legacy))
        assert error<1e-11
        scaled=scores_safe.normalized(y,k*1e-15,X,mu)
        scale_error=np.max(np.abs(safe-scaled))
        assert scale_error<1e-11
        zero=scores_safe.normalized(y,np.zeros_like(k),X,mu)
        assert np.all(zero==0)
        # Direct single-kernel cosine ranks must agree except for no
        # outcome-dependent positive common factor; these random cases
        # have strictly positive factors and no numerical boundary ties.
        pred=np.einsum('rbc,fc->rbf',X-mu,k[0])
        cos=np.abs(np.einsum('rf,rbf->rb',y,pred))/(np.linalg.norm(y,axis=1)[:,None]*np.linalg.norm(pred,axis=2))
        assert np.array_equal(np.argsort(cos,axis=1),np.argsort(safe[:,:,0],axis=1))
        save('normalized_implementation',design='fixed' if fixed else 'Bernoulli',variance_error=error,scale_error=scale_error,zero_kernel_pass=1)

    # Independently construct the selected ER Hard-3 response from shortest
    # paths rather than the supplied matrix-power implementation. Reuse only
    # the published graph generator/seed, not its scoring pipeline.
    import networkx as nx
    import revision_study
    gs=227554116
    graph,_=revision_study.graph('ER',240,gs)
    split=np.random.default_rng(gs+104729).permutation(240)
    focal,aux=np.sort(split[:120]),np.sort(split[120:])
    positions={node:i for i,node in enumerate(aux)}
    h=np.zeros((120,120))
    for i,node in enumerate(focal):
        distances=nx.single_source_shortest_path_length(graph,int(node),cutoff=3)
        for other,distance in distances.items():
            if other in positions and distance>0:h[i,positions[other]]=1
    h*=np.sqrt(120)/np.linalg.norm(h)
    gram=h.T@h
    reff=np.trace(gram)**2/np.sum(gram*gram)
    assert abs(reff-1.2342006863020152)<1e-10
    q=np.random.default_rng(2026101048)
    reps,B=2048,499
    hits={0:0,40:0,'noise_free':0}
    for start in range(0,reps,16):
        u=q.binomial(1,.4,size=(16,B+1,120))-.4
        noise=q.normal(size=(16,120))
        signal=u[:,0,:]@h.T
        for strength in hits:
            y=signal if strength=='noise_free' else noise+strength*signal
            weight=y@h
            scores=np.abs(np.einsum('rc,rbc->rb',weight,u))
            pv=(1+np.sum(scores[:,1:]>=scores[:,0,None]-1e-12,axis=1))/(B+1)
            hits[strength]+=np.sum(pv<=.05)
    for strength,count in hits.items():
        save('selected_ER_hard3',m=120,seed=gs,assignment_seed=2026101048,theta=strength,effective_rank=reff,replicates=reps,B=B,rate=count/reps)

    fields=list(dict.fromkeys(key for row in rows for key in row))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader();writer.writerows(rows)
    for row in rows:
        print(row)


if __name__=='__main__':
    main()
