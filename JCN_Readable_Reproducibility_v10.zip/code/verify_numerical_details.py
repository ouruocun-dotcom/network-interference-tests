#!/usr/bin/env python3
"""Check augmented moments and audit the known-parameter tail at delta=.85."""
from __future__ import annotations
import itertools
import json
import math
from pathlib import Path
from archive_paths import output_dir
import numpy as np
import pandas as pd

from empirical_paluck_test import standardize_scores
from validate_submission_comparators import Config, upper_p
from validate_diffusion_kernel_test import generate_graph, normalized_adjacency, tail_kernel_from_spectrum

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"


def check_moments() -> dict:
    # Two independent complete-randomization blocks, each choosing two of four.
    block = np.array([x for x in itertools.product((0, 1), repeat=4) if sum(x) == 2], dtype=float)
    design = np.array([np.r_[a, b] for a in block for b in block])
    weights = np.array([[1., 2., 0.], [-1., 1., 0.], [2., -2., 0.], [0., 3., 0.],
                        [1., -1., 0.], [3., 0., 0.], [-2., 2., 0.], [0., 1., 0.]])
    scores = (design - .5) @ weights
    variance = sum((2*2)/(4*3)*np.sum((weights[s:s+4]-weights[s:s+4].mean(axis=0))**2, axis=0) for s in (0, 4))
    err = float(np.max(np.abs(scores.var(axis=0)-variance)))
    assert err < 1e-12
    z, valid = standardize_scores(scores)
    assert valid.tolist() == [True, True, False]
    permutation = np.random.default_rng(717).permutation(len(scores))
    shuffled, shuffled_valid = standardize_scores(scores[permutation])
    assert np.array_equal(valid, shuffled_valid)
    assert np.allclose(shuffled[:, valid], z[permutation][:, valid], atol=1e-12)
    # B=2: all 6^3 augmented triples under a uniform block design.
    base = (block-.5) @ weights[:4, :2]
    triples = list(itertools.product(range(6), repeat=3))
    pvalues = []
    for indices in triples:
        s = base[list(indices)]
        sd = s.std(axis=0, ddof=1)
        active = sd > 1e-14
        if not active.any():
            pvalues.append(1.)
            continue
        standardized = (s[:, active]-s[:, active].mean(axis=0))/sd[active]
        implemented, kept = standardize_scores(s)
        assert np.array_equal(kept, active)
        assert np.allclose(implemented[:, kept], standardized, atol=1e-12)
        t = np.max(np.abs(standardized), axis=1)
        pvalues.append(np.mean(t >= t[0]-1e-12))
    pvalues = np.array(pvalues)
    for level in (1/3, 2/3, 1):
        assert np.mean(pvalues <= level+1e-12) <= level+1e-12
    return {"block_variance_max_error": err, "permutation_equivariance": True,
            "zero_variance_column_omitted": True, "augmented_triples_checked": len(triples),
            "null_rejection_at_one_third": float(np.mean(pvalues <= 1/3+1e-12))}


def main() -> None:
    checked = check_moments()
    cfg = Config()
    old = pd.read_csv(RESULTS / "results_submission_comparators" / "replicate_results.csv")
    scenarios = old[old.delta == .85][["graph", "graph_index", "graph_seed", "scenario_seed"]].drop_duplicates()
    rows = []
    for row in scenarios.itertuples(index=False):
        graph = generate_graph(row.graph, cfg.n, int(row.graph_seed))
        w = normalized_adjacency(graph)
        ev, evec = np.linalg.eigh(w)
        split = np.random.default_rng(int(row.graph_seed)+104729).permutation(cfg.n)
        f, c = np.sort(split[:cfg.n//2]), np.sort(split[cfg.n//2:])
        local = ((evec*ev[None, :]) @ evec.T)[np.ix_(f, c)]
        q = tail_kernel_from_spectrum(ev, evec, .85)
        generator = q*math.sqrt(cfg.n)/np.linalg.norm(q, "fro")
        raw = q[np.ix_(f, c)]
        residual = raw-(raw*local).sum()/(local**2).sum()*local
        rng = np.random.default_rng(int(row.scenario_seed))
        x = rng.binomial(1, cfg.treatment_probability, size=(cfg.assignments_per_graph, cfg.n)).astype(float)
        error = rng.normal(0, cfg.noise_sd, size=x.shape)
        y = cfg.direct_effect*x+cfg.contagion_strength*((x-cfg.treatment_probability)@generator.T)+error
        random = rng.binomial(1, cfg.treatment_probability,
                             size=(cfg.assignments_per_graph, cfg.randomizations, len(c))).astype(float)
        for name, kernel in (("unprojected_tail", raw), ("matched_tail", residual), ("one_hop", local)):
            a = y[:, f]@kernel
            sd = math.sqrt(cfg.treatment_probability*(1-cfg.treatment_probability))*np.linalg.norm(a, axis=1)
            obs = np.sum((x[:, c]-cfg.treatment_probability)*a, axis=1)/sd
            simulated = np.einsum("rba,ra->rb", random-cfg.treatment_probability, a)/sd[:, None]
            p = upper_p(obs, simulated)
            if name != "unprojected_tail":
                key = "oracle" if name == "matched_tail" else name
                target = old[(old.graph==row.graph)&(old.graph_index==row.graph_index)&(old.delta==.85)&(old.method==key)].sort_values("replicate").pvalue.to_numpy()
                assert np.allclose(p, target, rtol=0, atol=1e-12)
            for rep, value in enumerate(p):
                rows.append({"graph": row.graph, "graph_index": int(row.graph_index),
                             "scenario_seed": int(row.scenario_seed), "replicate": rep,
                             "method": name, "pvalue": value})
    out = output_dir("results_numerical_details")
    out.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(out/"matched_tail_replicates.csv", index=False)
    summary = frame.assign(reject=frame.pvalue<=.05).groupby(["graph", "method"]).reject.mean()
    summary.to_csv(out/"matched_tail_summary.csv")
    (out/"moment_checks.json").write_text(json.dumps(checked, indent=2), encoding="utf-8")
    print(json.dumps(checked, indent=2))
    print(summary.to_string())

if __name__ == "__main__":
    main()
