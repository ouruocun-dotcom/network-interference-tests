#!/usr/bin/env python3
"""Submission-level comparator study for adaptive diffusion randomization tests.

All methods use the same graphs, potential-outcome draws, observed assignments,
and Monte Carlo assignments.  The focal set is fixed before outcomes are drawn.
The test conditions on focal assignments and rerandomizes auxiliary assignments.
"""

from __future__ import annotations

import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import networkx as nx
import numpy as np
from scipy import stats

from validate_diffusion_kernel_test import (
    generate_graph,
    kernel_from_spectrum,
    normalized_adjacency,
    spectral_kernels,
    tail_kernel_from_spectrum,
)


@dataclass(frozen=True)
class Config:
    n: int = 240
    graph_replicates: int = 25
    assignments_per_graph: int = 32
    randomizations: int = 499
    treatment_probability: float = 0.4
    direct_effect: float = 0.5
    contagion_strength: float = 1.0
    noise_sd: float = 1.0
    graph_seed: int = 314159
    simulation_seed: int = 161803
    lambdas: tuple[float, ...] = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)
    deltas: tuple[float, ...] = (0.0, 0.3, 0.6, 0.85)


METHODS = ("elc", "score", "htn", "one_hop", "adaptive", "oracle")


def upper_p(observed: np.ndarray, randomized: np.ndarray) -> np.ndarray:
    return (1.0 + np.sum(randomized >= observed[:, None] - 1e-12, axis=1)) / (
        randomized.shape[1] + 1.0
    )


def safe_group_residuals(y: np.ndarray, treatment: np.ndarray) -> np.ndarray:
    """Residualize focal outcomes by their fixed own-treatment assignment."""
    residuals = np.empty_like(y)
    for row in range(y.shape[0]):
        overall = float(np.mean(y[row]))
        means = []
        for value in (0.0, 1.0):
            mask = treatment[row] == value
            means.append(float(np.mean(y[row, mask])) if np.any(mask) else overall)
        fitted = np.where(treatment[row] == 1.0, means[1], means[0])
        residuals[row] = y[row] - fitted
    return residuals


def htn_statistic(
    assignments: np.ndarray,
    fixed_counts: np.ndarray,
    adjacency_cross: np.ndarray,
    y_centered: np.ndarray,
) -> np.ndarray:
    """Correlation of focal outcomes with any-treated-neighbor exposure."""
    if assignments.ndim == 2:
        counts = assignments @ adjacency_cross.T + fixed_counts
        exposed = counts > 0.0
        centered = exposed - exposed.mean(axis=1, keepdims=True)
        numerator = np.mean(centered * y_centered, axis=1)
        denominator = np.std(exposed, axis=1) * np.std(y_centered, axis=1)
    else:
        counts = np.einsum("rba,fa->rbf", assignments, adjacency_cross, optimize=True)
        counts += fixed_counts[:, None, :]
        exposed = counts > 0.0
        centered = exposed - exposed.mean(axis=2, keepdims=True)
        numerator = np.mean(centered * y_centered[:, None, :], axis=2)
        denominator = np.std(exposed, axis=2) * np.std(y_centered, axis=1)[:, None]
    return np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator, dtype=float),
        where=denominator > 1e-14,
    )


def method_pvalues(
    y_focal: np.ndarray,
    x_focal: np.ndarray,
    x_auxiliary: np.ndarray,
    kernel_cross: np.ndarray,
    oracle_cross: np.ndarray,
    adjacency_ff: np.ndarray,
    adjacency_cross: np.ndarray,
    full_focal_degree: np.ndarray,
    probability: float,
    randomizations: int,
    rng: np.random.Generator,
) -> dict[str, np.ndarray]:
    reps, auxiliary_count = x_auxiliary.shape
    randomized_assignments = rng.binomial(
        1, probability, size=(reps, randomizations, auxiliary_count)
    ).astype(float)

    # ELC: edge-weighted treated-minus-control neighbor contrast.
    edge_y = y_focal @ adjacency_cross
    edge_count = adjacency_cross.sum(axis=0)

    def elc_stat(assignments: np.ndarray) -> np.ndarray:
        if assignments.ndim == 2:
            tr_num = np.sum(assignments * edge_y, axis=1)
            tr_den = np.sum(assignments * edge_count, axis=1)
            co_num = np.sum((1.0 - assignments) * edge_y, axis=1)
            co_den = np.sum((1.0 - assignments) * edge_count, axis=1)
        else:
            tr_num = np.einsum("rba,ra->rb", assignments, edge_y, optimize=True)
            tr_den = np.einsum("rba,a->rb", assignments, edge_count, optimize=True)
            co_num = np.einsum("rba,ra->rb", 1.0 - assignments, edge_y, optimize=True)
            co_den = np.einsum("rba,a->rb", 1.0 - assignments, edge_count, optimize=True)
        return tr_num / np.maximum(tr_den, 1e-14) - co_num / np.maximum(co_den, 1e-14)

    observed_elc = elc_stat(x_auxiliary)
    randomized_elc = elc_stat(randomized_assignments)

    # Score statistic: own-treatment residuals against treated-neighbor fraction.
    residuals = safe_group_residuals(y_focal, x_focal)
    valid_degree = np.maximum(full_focal_degree, 1.0)
    score_weights = np.einsum(
        "rf,fa->ra", residuals / valid_degree[None, :], adjacency_cross, optimize=True
    ) / y_focal.shape[1]
    observed_score = np.sum(x_auxiliary * score_weights, axis=1)
    randomized_score = np.einsum(
        "rba,ra->rb", randomized_assignments, score_weights, optimize=True
    )

    # HTN statistic, including fixed focal-neighbor assignments in exposure.
    fixed_counts = x_focal @ adjacency_ff.T
    y_centered = y_focal - y_focal.mean(axis=1, keepdims=True)
    observed_htn = htn_statistic(
        x_auxiliary, fixed_counts, adjacency_cross, y_centered
    )
    randomized_htn = htn_statistic(
        randomized_assignments, fixed_counts, adjacency_cross, y_centered
    )

    # One-hop and adaptive diffusion scores.
    weights = np.einsum("rf,lfa->ral", y_focal, kernel_cross, optimize=True)
    denominators = math.sqrt(probability * (1.0 - probability)) * np.linalg.norm(
        weights, axis=1
    )
    if np.any(denominators <= 1e-14):
        raise ValueError("zero-variance diffusion component in simulation")
    observed_z = np.einsum(
        "ra,ral->rl", x_auxiliary - probability, weights, optimize=True
    ) / denominators
    randomized_z = np.einsum(
        "rba,ral->rbl",
        randomized_assignments - probability,
        weights,
        optimize=True,
    ) / denominators[:, None, :]

    # Known-parameter matched-tail score: the supplied cross-block is the
    # generating tail after removal of its one-hop projection.
    oracle_weights = y_focal @ oracle_cross
    oracle_denominator = math.sqrt(probability * (1.0 - probability)) * np.linalg.norm(
        oracle_weights, axis=1
    )
    if np.any(oracle_denominator <= 1e-14):
        raise ValueError("zero-variance oracle component in simulation")
    observed_oracle = np.sum(
        (x_auxiliary - probability) * oracle_weights, axis=1
    ) / oracle_denominator
    randomized_oracle = np.einsum(
        "rba,ra->rb",
        randomized_assignments - probability,
        oracle_weights,
        optimize=True,
    ) / oracle_denominator[:, None]

    return {
        "elc": upper_p(observed_elc, randomized_elc),
        "score": upper_p(observed_score, randomized_score),
        "htn": upper_p(observed_htn, randomized_htn),
        "one_hop": upper_p(observed_z[:, 0], randomized_z[:, :, 0]),
        "adaptive": upper_p(
            np.max(observed_z, axis=1), np.max(randomized_z, axis=2)
        ),
        "oracle": upper_p(observed_oracle, randomized_oracle),
    }


def cluster_interval(values: np.ndarray) -> tuple[float, float]:
    mean = float(np.mean(values))
    critical = float(stats.t.ppf(0.975, len(values) - 1))
    half = critical * float(np.std(values, ddof=1) / math.sqrt(len(values)))
    return max(0.0, mean - half), min(1.0, mean + half)


def main() -> None:
    config = Config()
    output = output_dir("results_submission_comparators")
    output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    graph_rng = np.random.default_rng(config.graph_seed)
    simulation_rng = np.random.default_rng(config.simulation_seed)
    rows: list[dict[str, object]] = []
    graphs: list[dict[str, object]] = []

    for kind in ("ER", "SBM", "BA"):
        for graph_index in range(config.graph_replicates):
            graph_seed = int(graph_rng.integers(0, 2**31 - 1))
            graph = generate_graph(kind, config.n, graph_seed)
            adjacency = nx.to_numpy_array(graph, dtype=float)
            normalized = normalized_adjacency(graph)
            kernels, eigenvalues, eigenvectors = spectral_kernels(
                normalized, config.lambdas
            )
            split = np.random.default_rng(graph_seed + 104729).permutation(config.n)
            focal = np.sort(split[: config.n // 2])
            auxiliary = np.sort(split[config.n // 2 :])
            kernel_cross = kernels[:, focal][:, :, auxiliary].copy()
            local_cross = kernel_cross[0]
            local_energy = float(np.sum(local_cross**2))
            for index in range(1, len(kernel_cross)):
                projection = float(np.sum(kernel_cross[index] * local_cross)) / max(
                    local_energy, 1e-14
                )
                kernel_cross[index] -= projection * local_cross
            adjacency_ff = adjacency[np.ix_(focal, focal)]
            adjacency_cross = adjacency[np.ix_(focal, auxiliary)]
            focal_degree = adjacency[focal].sum(axis=1)
            graphs.append(
                {
                    "graph": kind,
                    "graph_index": graph_index,
                    "graph_seed": graph_seed,
                    "nodes": config.n,
                    "edges": graph.number_of_edges(),
                    "mean_degree": 2.0 * graph.number_of_edges() / config.n,
                }
            )

            for delta in config.deltas:
                scenario_seed = int(simulation_rng.integers(0, 2**63 - 1))
                rng = np.random.default_rng(scenario_seed)
                treatment = rng.binomial(
                    1,
                    config.treatment_probability,
                    size=(config.assignments_per_graph, config.n),
                ).astype(float)
                error = rng.normal(
                    0.0,
                    config.noise_sd,
                    size=(config.assignments_per_graph, config.n),
                )
                if delta == 0.0:
                    causal_kernel = np.zeros((config.n, config.n))
                    oracle = normalized.copy()
                else:
                    causal_kernel = tail_kernel_from_spectrum(
                        eigenvalues, eigenvectors, delta
                    )
                    causal_kernel *= math.sqrt(config.n) / np.linalg.norm(
                        causal_kernel, ord="fro"
                    )
                    oracle = tail_kernel_from_spectrum(
                        eigenvalues, eigenvectors, delta
                    )
                np.fill_diagonal(oracle, 0.0)
                oracle_cross = oracle[np.ix_(focal, auxiliary)].copy()
                if delta > 0.0:
                    oracle_cross -= (
                        float(np.sum(oracle_cross * local_cross))
                        / max(local_energy, 1e-14)
                    ) * local_cross
                outcome = (
                    config.direct_effect * treatment
                    + config.contagion_strength
                    * ((treatment - config.treatment_probability) @ causal_kernel.T)
                    + error
                )
                pvalues = method_pvalues(
                    outcome[:, focal],
                    treatment[:, focal],
                    treatment[:, auxiliary],
                    kernel_cross,
                    oracle_cross,
                    adjacency_ff,
                    adjacency_cross,
                    focal_degree,
                    config.treatment_probability,
                    config.randomizations,
                    rng,
                )
                for method in METHODS:
                    for replicate, pvalue in enumerate(pvalues[method]):
                        rows.append(
                            {
                                "graph": kind,
                                "graph_index": graph_index,
                                "graph_seed": graph_seed,
                                "delta": delta,
                                "method": method,
                                "replicate": replicate,
                                "scenario_seed": scenario_seed,
                                "pvalue": float(pvalue),
                            }
                        )

    with (output / "replicate_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (output / "graph_details.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(graphs[0]))
        writer.writeheader()
        writer.writerows(graphs)

    summaries: list[dict[str, object]] = []
    for kind in ("ER", "SBM", "BA"):
        for delta in config.deltas:
            for method in METHODS:
                subset = [
                    row
                    for row in rows
                    if row["graph"] == kind
                    and row["delta"] == delta
                    and row["method"] == method
                ]
                pvalues = np.asarray([row["pvalue"] for row in subset], dtype=float)
                graph_rates = np.asarray(
                    [
                        np.mean(
                            [
                                row["pvalue"] <= 0.05
                                for row in subset
                                if row["graph_index"] == graph_index
                            ]
                        )
                        for graph_index in range(config.graph_replicates)
                    ],
                    dtype=float,
                )
                low, high = cluster_interval(graph_rates)
                summaries.append(
                    {
                        "graph": kind,
                        "delta": delta,
                        "method": method,
                        "rejection_rate": float(np.mean(pvalues <= 0.05)),
                        "cluster_ci_low": low,
                        "cluster_ci_high": high,
                        "datasets": len(pvalues),
                        "mean_pvalue": float(np.mean(pvalues)),
                    }
                )
    with (output / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    with (output / "config.json").open("w", encoding="utf-8") as handle:
        json.dump(asdict(config), handle, indent=2)
    with (output / "run_metadata.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "elapsed_seconds": time.perf_counter() - started,
                "methods": METHODS,
                "paired_design": True,
            },
            handle,
            indent=2,
        )
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
