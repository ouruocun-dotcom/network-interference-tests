#!/usr/bin/env python3
"""Primary-outcome sensitivity to the direction assigned to peer nominations."""

from __future__ import annotations

import json
import time
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.sparse.linalg import splu

from empirical_paluck_test import (
    LAMBDAS,
    kernel_family,
    normalized_adjacency,
    randomization_matrix,
    standardize_scores,
    valid_numeric,
)


CACHE = output_dir("results_paluck_primary_50k") / "decoded_needed.pkl"
OUTPUT = output_dir("results_paluck_direction_sensitivity_50k")
RANDOMIZATIONS = 49_999
SEED = 20260901
OUTCOME = "WRISTOW2"
MODES = ("undirected", "nominator_to_nominee", "nominee_to_nominator")


def directed_kernel_family(adjacency: np.ndarray) -> np.ndarray:
    """Return random-walk resolvent components for a directed adjacency."""
    row_degree = adjacency.sum(axis=1)
    inverse = np.zeros_like(row_degree)
    positive = row_degree > 0
    inverse[positive] = 1.0 / row_degree[positive]
    transition = sparse.csc_matrix(inverse[:, None] * adjacency)
    identity = sparse.eye(adjacency.shape[0], format="csc")
    kernels = [transition.toarray()]
    for parameter in LAMBDAS[1:]:
        factor = splu(identity - parameter * transition)
        resolved = factor.solve(transition.toarray())
        tail = resolved - transition.toarray()
        np.fill_diagonal(tail, 0.0)
        kernels.append(tail)
    return np.asarray(kernels)


def clean_school(school: pd.DataFrame) -> pd.DataFrame:
    ids = school["ID"].to_numpy(dtype=float)
    school = school.loc[np.isfinite(ids) & (ids > 0) & (ids != 999)].copy()
    if school["ID"].duplicated(keep=False).any():
        keep = []
        for _, group in school.groupby("ID", sort=False):
            if len(group) == 1:
                keep.append(group.index[0])
            else:
                eligible = group.loc[group["TREAT"].notna() & group["STRB"].notna()]
                if len(eligible) != 1:
                    raise ValueError("Ambiguous duplicate roster ID")
                keep.append(eligible.index[0])
        school = school.loc[keep].copy()
    if school["ID"].duplicated().any():
        raise ValueError("Duplicate roster ID remains after cleanup")
    return school


def school_piece(school: pd.DataFrame, mode: str) -> dict | None:
    school = clean_school(school)
    ids = school["ID"].to_numpy(dtype=int)
    id_to_index = {student_id: index for index, student_id in enumerate(ids)}
    directed = np.zeros((len(ids), len(ids)), dtype=float)
    for source, (_, row) in enumerate(school.iterrows()):
        for column in (f"ST{i}" for i in range(1, 11)):
            target_value = row[column]
            if not np.isfinite(target_value) or target_value < 0:
                continue
            target = id_to_index.get(int(target_value))
            if target is not None and target != source:
                directed[source, target] = 1.0

    if mode == "undirected":
        adjacency = ((directed + directed.T) > 0).astype(float)
        kernels = kernel_family(normalized_adjacency(adjacency))
    elif mode == "undirected_row":
        adjacency = ((directed + directed.T) > 0).astype(float)
        kernels = directed_kernel_family(adjacency)
    elif mode == "nominator_to_nominee":
        adjacency = directed
        kernels = directed_kernel_family(adjacency)
    elif mode == "nominee_to_nominator":
        adjacency = directed.T
        kernels = directed_kernel_family(adjacency)
    else:
        raise ValueError(mode)

    treatment = school["TREAT"].to_numpy(dtype=float)
    strata = school["STRB"].to_numpy(dtype=float)
    outcome = school[OUTCOME].to_numpy(dtype=float)
    focal = np.flatnonzero(treatment == 0)
    auxiliary = np.flatnonzero(
        np.isin(treatment, (1, 2)) & np.isfinite(strata) & (strata > 0)
    )
    if len(focal) == 0 or len(auxiliary) == 0:
        return None
    if not np.all(valid_numeric(outcome[focal])):
        raise ValueError("WRISTOW2 is incomplete for the outcome-free focal set")

    cross = kernels[:, focal][:, :, auxiliary].copy()
    local = cross[0]
    energy = float(np.sum(local**2))
    for index in range(1, len(cross)):
        projection = float(np.sum(cross[index] * local)) / max(energy, 1e-14)
        cross[index] -= projection * local
    weights = np.einsum("f,lfa->al", outcome[focal], cross, optimize=True)
    raw_cross = adjacency[np.ix_(focal, auxiliary)]
    return {
        "observed": (treatment[auxiliary] == 1).astype(float),
        "weights": weights,
        "elc_weights": outcome[focal] @ raw_cross,
        "elc_counts": raw_cross.sum(axis=0),
        "block_labels": [
            (int(school.iloc[index]["SCHID"]), int(strata[index]))
            for index in auxiliary
        ],
        "nodes": len(ids),
        "arcs": int(adjacency.sum()),
        "focal": len(focal),
    }


def combine(frame: pd.DataFrame, mode: str) -> dict:
    treated = frame.loc[frame["SCHTREAT"] == 1]
    pieces = []
    for school_id in sorted(treated["SCHID"].dropna().unique()):
        piece = school_piece(treated.loc[treated["SCHID"] == school_id].copy(), mode)
        if piece is not None:
            pieces.append(piece)
    return {
        "observed": np.concatenate([piece["observed"] for piece in pieces]),
        "weights": np.concatenate([piece["weights"] for piece in pieces], axis=0),
        "elc_weights": np.concatenate([piece["elc_weights"] for piece in pieces]),
        "elc_counts": np.concatenate([piece["elc_counts"] for piece in pieces]),
        "block_labels": [label for piece in pieces for label in piece["block_labels"]],
        "schools": len(pieces),
        "nodes": int(sum(piece["nodes"] for piece in pieces)),
        "arcs": int(sum(piece["arcs"] for piece in pieces)),
        "focal": int(sum(piece["focal"] for piece in pieces)),
    }


def pvalue(statistic: np.ndarray) -> float:
    return float(np.mean(statistic >= statistic[0] - 1e-12))


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    frame = pd.read_pickle(CACHE)
    analyses = {mode: combine(frame, mode) for mode in MODES}
    reference = analyses["undirected"]
    for analysis in analyses.values():
        if not np.array_equal(analysis["observed"], reference["observed"]):
            raise ValueError("Auxiliary assignments differ by network orientation")
        if analysis["block_labels"] != reference["block_labels"]:
            raise ValueError("Randomization blocks differ by network orientation")

    assignments, probabilities = randomization_matrix(
        reference["observed"],
        reference["block_labels"],
        RANDOMIZATIONS,
        np.random.default_rng(SEED),
    )
    centered = assignments.astype(float) - probabilities[None, :]
    results = []
    for mode, analysis in analyses.items():
        scores = centered @ analysis["weights"]
        z, valid_components = standardize_scores(scores)
        if not valid_components[0]:
            raise ValueError("the one-hop component has zero conditional variance")
        one_hop = z[:, 0]
        adaptive = np.max(z[:, valid_components], axis=1)
        adaptive_two_sided = np.max(np.abs(z[:, valid_components]), axis=1)
        treated_num = assignments @ analysis["elc_weights"]
        treated_den = assignments @ analysis["elc_counts"]
        control_num = (1 - assignments) @ analysis["elc_weights"]
        control_den = (1 - assignments) @ analysis["elc_counts"]
        elc = treated_num / np.maximum(treated_den, 1e-14) - control_num / np.maximum(
            control_den, 1e-14
        )
        results.append(
            {
                "orientation": mode,
                "normalization": (
                    "symmetric" if mode == "undirected" else "row_random_walk"
                ),
                "schools": analysis["schools"],
                "nodes": analysis["nodes"],
                "arcs": analysis["arcs"],
                "focal_units": analysis["focal"],
                "auxiliary_units": len(reference["observed"]),
                "p_elc": pvalue(elc),
                "p_one_hop": pvalue(one_hop),
                "p_adaptive": pvalue(adaptive),
                "p_adaptive_two_sided": pvalue(adaptive_two_sided),
                "observed_one_hop_z": float(one_hop[0]),
                "observed_adaptive_z": float(adaptive[0]),
                "selected_lambda": float(LAMBDAS[int(np.nanargmax(z[0]))]),
                "component_z": [float(value) for value in z[0]],
            }
        )
    payload = {
        "outcome": OUTCOME,
        "randomizations": RANDOMIZATIONS,
        "seed": SEED,
        "interpretation": {
            "nominator_to_nominee": "a focal nominator may respond to a treated nominee",
            "nominee_to_nominator": "a focal nominee may respond to a treated nominator",
        },
        "results": results,
        "elapsed_seconds": time.perf_counter() - started,
    }
    with (OUTPUT / "direction_sensitivity.json").open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
