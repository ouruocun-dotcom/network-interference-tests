"""(i) Strong-signal limit under Bernoulli vs fixed-count designs for the matched
kernel; (ii) effective ranks r_eff(H) and r_eff(H Pi) of response operators across
the eight n=240 ensembles (independent seed 2026101001)."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
P, B, ALPHA = .4, 499, .05

def reff(m):
    s2 = np.linalg.svd(m, compute_uv=False)**2
    return float(s2.sum()**2/np.sum(s2**2))

def draw(rng, shape, fixed):
    m = shape[-1]
    if not fixed:
        return (rng.random(shape) < P) - P
    k = int(np.floor(P*m)); x = np.zeros(shape)
    idx = np.argsort(rng.random(shape), axis=-1)[..., :k]
    np.put_along_axis(x, idx, 1.0, axis=-1)
    return x - k/m

def limit_power(h, k, rng, reps, fixed):
    """Noise-free finite-B test: compare |w'U| and |w'U*|, w = K'H U."""
    m = h.shape[1]; M = k.T@h; rej = 0
    for start in range(0, reps, 20):
        kk = min(20, reps-start)
        U = draw(rng, (kk, m), fixed); Us = draw(rng, (kk, B, m), fixed)
        w = U@M.T
        t0 = np.abs(np.sum(w*U, axis=1)); ts = np.abs(np.einsum('kbm,km->kb', Us, w))
        rej += int(np.sum((1+np.sum(ts >= t0[:, None]-1e-12, axis=1))/(B+1) <= ALPHA))
    return rej/reps

rng = np.random.default_rng(2026101001); rows = []
for kind in r.KINDS:
    for gi in range(6):
        gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
        a = np.asarray(__import__('networkx').to_numpy_array(g, nodelist=range(240)))
        split = np.random.default_rng(gs+104729).permutation(240)
        f, c = np.sort(split[:120]), np.sort(split[120:])
        w, eig, u, *_ = r.prepare(a, f, c)
        dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
        cross = lambda x: x[np.ix_(f, c)]
        ops = {'local_W': cross(w), 'hard2': cross((dist <= 2)*1.), 'hard3': cross((dist <= 3)*1.),
               'decay': cross(np.exp(-(dist-1)/1.5)),
               'tail_0.1': cross((u*(.1*eig**2/(1-.1*eig)))@u.T),
               'tail_0.95': cross((u*(.95*eig**2/(1-.95*eig)))@u.T)}
        for name, h in ops.items():
            h = r.scale(h); hp = h - h.mean(axis=1, keepdims=True)
            row = dict(kind=kind, graph=gi, operator=name, reff_H=reff(h), reff_HPi=reff(hp))
            if name in ('hard2', 'hard3', 'decay', 'tail_0.95') and gi < 3:
                row['limit_bern'] = limit_power(h, h, rng, 400, False)
                row['limit_fixed'] = limit_power(h, h, rng, 400, True)
            rows.append(row)
        pd.DataFrame(rows).to_csv(OUT/'design_topology.csv', index=False)
        print(kind, gi, flush=True)
