"""Structured (degree-based) focal/auxiliary roles versus random balanced splits.
Six graphs per ensemble, 128 datasets per split and mechanism, designated
Bernoulli W/G-residual bank (studentized and normalized). Roles depend only on
degrees (ties broken by a fixed random order), so Theorem 1 applies.
Seed 2026101015. Response operators use one per-pair scale per graph (that of\nthe random split), so splits are compared at a fixed per-pair effect."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
import scores_fast as S
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101015); rows = []; n = 240
THETA = {'null': 0.0, 'hard2': 0.5, 'hard3': 1.0, 'decay': 0.5}
for kind in r.KINDS:
    for gi in range(6):
        gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, n, gs)
        a = nx.to_numpy_array(g, nodelist=range(n)); deg = a.sum(1)
        dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
        tie = rng.permutation(n); order = np.lexsort((tie, deg))     # ascending degree
        splits = {'random': np.random.default_rng(gs+104729).permutation(n),
                  'focal_low_degree': order, 'focal_high_degree': order[::-1]}
        X, mu = S.draws(rng, (128, 500, 120), False); noise = rng.normal(size=(128, 120))
        resp = {'hard2': (dist <= 2)*1., 'hard3': (dist <= 3)*1., 'decay': np.exp(-(dist-1)/1.5)}
        f0 = np.sort(splits['random'][:120]); c0 = np.sort(splits['random'][120:])
        # fixed per-pair effect: one scale per graph, taken from the random split
        scale0 = {m_: np.sqrt(120/np.sum(h[np.ix_(f0, c0)]**2)) for m_, h in resp.items()}
        for label, sp in splits.items():
            f, c = np.sort(sp[:120]), np.sort(sp[120:])
            w, eig, u, k, groups, *_ = r.prepare(a, f, c); kk = k[groups['orth_degree_max']]
            kxn = S.kx_norms(kk, X, mu)
            for mech, th in THETA.items():
                y = noise if mech == 'null' else th*(X[:, 0, :]-mu)@(scale0[mech]*resp[mech][np.ix_(f, c)]).T + noise
                for stat, t in (('studentized', S.score_z(y, kk, X, mu, False)), ('normalized', S.normalized(y, kk, X, mu, kxn))):
                    rows.append(dict(kind=kind, graph=gi, split=label, mechanism=mech, statistic=stat,
                                     rate=float(np.mean(S.rank_p(np.max(t, axis=2)) <= .05)),
                                     focal_mean_degree=float(deg[f].mean()), aux_mean_degree=float(deg[c].mean())))
        pd.DataFrame(rows).to_csv(OUT/'structured_split.csv', index=False)
        print(kind, gi, flush=True)
