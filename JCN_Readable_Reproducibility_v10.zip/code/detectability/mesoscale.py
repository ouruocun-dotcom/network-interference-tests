"""Corollary 1(b): block-level response on a two-block SBM. H_ij depends only on
(block of i, block of j). Matched studentized vs normalized scores, theta in
{1, 1e4}, Bernoulli / complete / block-stratified assignment. Seed 2026101006."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101006); m = 120; p = .4; B = 499; R = 1000
bF = np.repeat([0, 1], 60); bC = rng.permutation(np.repeat([0, 1], 60))
Hb = np.array([[1.0, .3], [.2, .8]]); H = Hb[bF][:, bC]; H *= np.sqrt(m/np.sum(H*H))
def draw(shape, design):
    if design == 'Bernoulli': return (rng.random(shape) < p) - p
    x = np.zeros(shape)
    groups = [np.arange(m)] if design == 'complete' else [np.where(bC == g)[0] for g in (0, 1)]
    for idx in groups:
        k = int(p*len(idx)); order = np.argsort(rng.random(shape[:-1] + (len(idx),)), axis=-1)[..., :k]
        sub = np.zeros(shape[:-1] + (len(idx),)); np.put_along_axis(sub, order, 1., axis=-1)
        x[..., idx] = sub - k/len(idx)
    return x
rows = []
for design in ('Bernoulli', 'complete', 'stratified'):
    for theta in (1.0, 1e4):
        hs = hc = 0
        for _ in range(R):
            U = draw((m,), design); Us = draw((B, m), design)
            Y = theta*H@U + rng.normal(size=m)
            a = H.T@Y; t0 = abs(a@U); hs += (1+np.sum(np.abs(Us@a) >= t0*(1-1e-9)))/(B+1) <= .05
            HU = H@U; HUs = Us@H.T; nu = np.linalg.norm(HU)
            c0 = abs(Y@HU)/nu if nu > 1e-12 else 0.0
            nus = np.linalg.norm(HUs, axis=1)
            cs = np.divide(np.abs(HUs@Y), nus, out=np.zeros(B), where=nus > 1e-12)
            hc += (1+np.sum(cs >= c0*(1-1e-9)))/(B+1) <= .05 if c0 > 0 else 0
        rows.append(dict(design=design, theta=theta, studentized=hs/R, normalized=hc/R))
        print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv(OUT/'mesoscale.csv', index=False)
