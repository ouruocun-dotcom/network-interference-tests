"""Synthetic rank experiment: m=200, Bernoulli(0.4) and fixed counts, H of rank r
with equal singular values, ||H||_F^2=m, matched kernel, B=199, 1000 replicates,
seed 2026101004; ties use a relative tolerance 1e-9. Compares studentized and assignment-normalized scores."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import chi2, norm
OUT = Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101004); m, p, B, R = 200, .4, 199, 1000
def draw(shape, fixed):
    if not fixed: return (rng.random(shape) < p) - p
    k = int(p*m); x = np.zeros(shape)
    np.put_along_axis(x, np.argsort(rng.random(shape), axis=-1)[..., :k], 1., axis=-1); return x - k/m
rows = []
for fixed in (False, True):
    for r in (1, 2, 3, 4, 6, 8, 12, 16, 32):
        for theta in (0.5, 1.0, 2.0, 1e4):
            hs = hc = 0
            for _ in range(R):
                V = np.linalg.qr(rng.normal(size=(m, r)))[0]; A = np.linalg.qr(rng.normal(size=(m, r)))[0]
                if fixed: V = np.linalg.qr(V - V.mean(0))[0]          # columns orthogonal to 1
                H = A@V.T*np.sqrt(m/r)
                U = draw(m, fixed); Us = draw((B, m), fixed)
                Y = theta*H@U + rng.normal(size=m)
                a = H.T@Y; t0 = abs(a@U); hs += (1+np.sum(np.abs(Us@a) >= t0*(1-1e-9)))/(B+1) <= .05
                HU = H@U; HUs = Us@H.T
                c0 = abs(Y@HU)/np.linalg.norm(HU); cs = np.abs(HUs@Y)/np.linalg.norm(HUs, axis=1)
                hc += (1+np.sum(cs >= c0*(1-1e-9)))/(B+1) <= .05
            rows.append(dict(design='fixed' if fixed else 'Bernoulli', rank=r, theta=theta,
                             studentized=hs/R, normalized=hc/R,
                             ceiling_theory=float(chi2.sf(norm.ppf(.975)**2, r))))
            pd.DataFrame(rows).to_csv(OUT/'synthetic_rank.csv', index=False)
            print(rows[-1], flush=True)
