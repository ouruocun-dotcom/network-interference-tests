"""Graph-only partition design. For each graph, the focal/auxiliary split is
chosen before outcomes to maximize a detectability criterion for a prespecified
response family {Hard 2, Hard 3, distance decay}:
    J(split) = min_H max_l <K_l, H>_F / ||K_l||_F      (H scaled to ||H||_F^2=|F|)
over the designated bank (Bernoulli: W/G-residual bank). The weak-signal
alignment is the local noncentrality of Section 3 / Proposition 3. Candidates:
the study's default random split plus N further random balanced splits.
Power of the default and optimized splits is compared on common assignments and
noise; theta chosen per mechanism; seed 2026101013."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
import scores_fast as S
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
NCAND = int(sys.argv[3]) if len(sys.argv) > 3 else 200
GRAPHS, REPS, n = 6, 64, 240
THETA = {'hard2': 0.5, 'hard3': 1.0, 'decay': 0.5}

def full_kernels(a):
    w, p_, degree = r.normalized(a)
    eig, u = np.linalg.eigh(w)
    tails = [(u*(lam*eig**2/(1-lam*eig)))@u.T for lam in r.GRID]
    dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
    resp = {'hard2': (dist <= 2)*1., 'hard3': (dist <= 3)*1., 'decay': np.exp(-(dist-1)/1.5)}
    return w, degree, tails, resp

def bank_for(f, c, w, degree, tails):
    cross = lambda x: x[np.ix_(f, c)]
    local, central = cross(w), cross(degree)
    comps = [local] + [r.project(cross(q), [local, central]) for q in tails]
    return np.array(comps)

def criterion(k, hs):
    kn = np.sqrt(np.sum(k*k, axis=(1, 2)))
    vals = []
    for h in hs.values():
        al = np.abs(np.einsum('lfc,fc->l', k, h))/np.maximum(kn, 1e-12)
        vals.append(al.max())
    return min(vals), vals

rng = np.random.default_rng(2026101013); rows = []; crit_rows = []
for kind in r.KINDS:
    for gi in range(GRAPHS):
        gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, n, gs)
        a = nx.to_numpy_array(g, nodelist=range(n)); deg = a.sum(1)
        w, degree, tails, resp = full_kernels(a)
        splits = [np.random.default_rng(gs+104729).permutation(n)]
        cand_rng = np.random.default_rng(gs+7)
        splits += [cand_rng.permutation(n) for _ in range(NCAND)]
        best = None
        for si, sp in enumerate(splits):
            f, c = np.sort(sp[:n//2]), np.sort(sp[n//2:])
            k = bank_for(f, c, w, degree, tails)
            hs = {m_: r.scale(h[np.ix_(f, c)]) for m_, h in resp.items()}
            J, vals = criterion(k, hs)
            crit_rows.append(dict(kind=kind, graph=gi, split=si, J=J, **{f'align_{m_}': v for m_, v in zip(hs, vals)},
                                  focal_mean_degree=deg[f].mean()))
            if si == 0: default = (J, f, c)
            if best is None or J > best[0]: best = (J, f, c)
        for label, (J, f, c) in (('default', default), ('optimized', best)):
            k = bank_for(f, c, w, degree, tails)
            hs = {m_: r.scale(h[np.ix_(f, c)]) for m_, h in resp.items()}
            X, mu = S.draws(np.random.default_rng(gs+99), (REPS, 500, n//2), False)
            noise = np.random.default_rng(gs+98).normal(size=(REPS, n//2))
            kxn = S.kx_norms(k, X, mu)
            for mech, th in [('null', 0.0)] + list(THETA.items()):
                y = noise if mech == 'null' else th*(X[:, 0, :]-mu)@hs[mech].T + noise
                for stat, t in (('studentized', S.score_z(y, k, X, mu, False)), ('normalized', S.normalized(y, k, X, mu, kxn))):
                    rej = S.rank_p(np.max(t, axis=2)) <= .05
                    rows.append(dict(kind=kind, graph=gi, split=label, J=J, mechanism=mech, theta=th, statistic=stat,
                                     rate=float(rej.mean()), focal_mean_degree=float(deg[f].mean())))
        pd.DataFrame(rows).to_csv(OUT/'partition_power.csv', index=False)
        pd.DataFrame(crit_rows).to_csv(OUT/'partition_criterion.csv', index=False)
        print(kind, gi, round(default[0], 3), round(best[0], 3), flush=True)
