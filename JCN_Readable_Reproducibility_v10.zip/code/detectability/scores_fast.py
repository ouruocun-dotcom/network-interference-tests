"""BLAS versions of the studentized and normalized scores (same definitions as
normalized_scores.py). Shapes: y (R,F), k (L,F,C), X (R,B1,C)."""
import numpy as np
P = .4

def draws(rng, shape, fixed):
    if not fixed:
        return (rng.random(shape) < P).astype(float), P
    m = shape[-1]; k = int(np.floor(P*m)); x = np.zeros(shape)
    np.put_along_axis(x, np.argsort(rng.random(shape), axis=-1)[..., :k], 1.0, axis=-1)
    return x, k/m

def rank_p(t):
    t0 = t[:, :1]
    return (np.sum(t[:, 1:] >= t0 - 1e-12*np.maximum(1, np.abs(t0)), axis=1)+1)/t.shape[1]

def weights(y, k):
    return np.einsum('rf,kfc->rkc', y, k, optimize=True)          # a = K'y  (R,L,C)

def score_z(y, k, X, mu, fixed):
    a = weights(y, k)
    if fixed:
        m = X.shape[-1]; kk = mu*m
        var = (kk/m)*(1-kk/m)*m/(m-1)*np.sum((a-a.mean(-1, keepdims=True))**2, -1)
    else:
        var = P*(1-P)*np.sum(a*a, -1)
    s = np.matmul(X-mu, np.transpose(a, (0, 2, 1)))               # (R,B1,L)
    return np.abs(s)/np.sqrt(np.maximum(var, 1e-300))[:, None, :]

def kx_norms(k, X, mu):
    """||K_l (x-mu)|| for every assignment: (R,B1,L) via one GEMM."""
    L, F, C = k.shape
    G = (X-mu).reshape(-1, C) @ k.reshape(L*F, C).T               # (R*B1, L*F)
    return np.sqrt(np.sum(G.reshape(-1, L, F)**2, -1)).reshape(X.shape[0], X.shape[1], L)

def normalized(y, k, X, mu, kxn):
    a = weights(y, k)
    num = np.abs(np.matmul(X-mu, np.transpose(a, (0, 2, 1))))     # |y'K(x-mu)| = |a'(x-mu)|
    kf = np.sqrt(np.sum(k*k, axis=(1, 2)))
    den = kxn*(np.linalg.norm(a, axis=-1)/kf)[:, None, :]
    return np.divide(num, den, out=np.zeros_like(num), where=den > 1e-12)
