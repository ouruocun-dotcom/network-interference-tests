"""Score functions shared by the normalized-score studies."""
import numpy as np
P = .4

def draws(rng, shape, fixed):
    if not fixed:
        return (rng.random(shape) < P).astype(float), P
    m = shape[-1]; k = int(np.floor(P*m)); x = np.zeros(shape)
    np.put_along_axis(x, np.argsort(rng.random(shape), axis=-1)[..., :k], 1.0, axis=-1)
    return x, k/m

def rank_p(t):
    return (np.sum(t[:, 1:] >= t[:, :1]-1e-12, axis=1)+1)/t.shape[1]

def score_z(y, k, X, mu, fixed):
    """paper statistic: a=K'y, Z=a'(x-mu)/sd(a), sd from design (analytic)."""
    a = np.einsum('rf,kfc->rkc', y, k)                       # (R,L,C)
    if fixed:
        m = X.shape[-1]; kk = mu*m
        var = (kk/m)*(1-kk/m)*m/(m-1)*np.sum((a-a.mean(-1, keepdims=True))**2, -1)
    else:
        var = P*(1-P)*np.sum(a*a, -1)
    s = np.einsum('rbc,rkc->rbk', X-mu, a)
    return np.abs(s)/np.sqrt(np.maximum(var, 1e-300))[:, None, :]

def cosine(y, k, kx, kxn):
    """assignment-normalized score: Z_l * ||K_l||_F sd_x / ||K_l (x-mu)||.
    For one kernel its ranks equal those of |cos(y, K(x-mu))|; the factor
    ||y|| ||K_l||_F / ||K_l' y|| (constant over reassignments) puts bank
    components on a common null scale."""
    num = np.abs(np.einsum('rf,rbkf->rbk', y, kx))
    kf = np.sqrt(np.sum(k*k, axis=(1, 2)))
    kty = np.linalg.norm(np.einsum('rf,kfc->rkc', y, k), axis=-1)
    den = kxn*(kty/kf)[:, None, :]
    return np.divide(num, den, out=np.zeros_like(num), where=den > 1e-12)

