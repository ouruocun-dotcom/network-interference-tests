"""Principal null audit of normalized and studentized banks, matching the size of
Table 4: eight ensembles x 10 graphs x 256 outcomes per design (20,480 per design),
B=499, seed 2026101010. Graphs are drawn independently for each design."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
import scores_fast as S
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101010); rows = []
for kind in r.KINDS:
    for gi in range(10):
        for fixed in (False, True):
            gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
            a = nx.to_numpy_array(g, nodelist=range(240))
            sp = np.random.default_rng(gs+104729).permutation(240)
            f, c = np.sort(sp[:120]), np.sort(sp[120:])
            w, eig, u, k, groups, *_ = r.prepare(a, f, c)
            banks = {'onehop': groups['onehop'], 'raw': groups['raw_max'], 'controlled': groups['orth_degree_max']}
            idx = sorted(set(sum(banks.values(), [])))
            kk = k[idx]; pos = {j: i for i, j in enumerate(idx)}
            rej = {(b, s): 0 for b in banks for s in ('score', 'normalized')}
            for chunk in range(4):
                X, mu = S.draws(rng, (64, 500, 120), fixed); y = rng.normal(size=(64, 120))
                zs = S.score_z(y, kk, X, mu, fixed); cs = S.normalized(y, kk, X, mu, S.kx_norms(kk, X, mu))
                for b, ids in banks.items():
                    cols = [pos[j] for j in ids]
                    for s, t in (('score', zs), ('normalized', cs)):
                        rej[(b, s)] += int(np.sum(S.rank_p(np.max(t[:, :, cols], axis=2)) <= .05))
            for (b, s), v in rej.items():
                rows.append(dict(design='fixed' if fixed else 'Bernoulli', kind=kind, graph=gi, seed=gs,
                                 bank=b, statistic=s, rejects=v, rate=v/256))
            pd.DataFrame(rows).to_csv(OUT/'null_full.csv', index=False)
            print(kind, gi, 'fixed' if fixed else 'bern', flush=True)
