"""Exploratory spectral diagnostics; effective rank is not a universal bound."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import chi2, norm

R = Path(sys.argv[1]); OUT = Path(sys.argv[2])
BLUE, ORANGE, INK, MUTED = '#2a78d6', '#eb6834', '#2b2b28', '#8a8983'
Z2 = norm.ppf(.975)**2
plt.rcParams.update({'font.size': 8, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.edgecolor': MUTED, 'axes.labelcolor': INK, 'xtick.color': MUTED,
                     'ytick.color': MUTED, 'axes.grid': True, 'grid.color': '#e6e5e0',
                     'grid.linewidth': .5, 'legend.frameon': False})
fig, ax = plt.subplots(2, 2, figsize=(6.6, 5.4))

# (a) synthetic rank-r operators, theta = 1e4
s = pd.read_csv(R/'out_syn/synthetic_rank.csv')
s = s[(s.design == 'Bernoulli') & (s.theta == 1e4)]
rr = np.geomspace(1, 32, 200)
a = ax[0, 0]
a.plot(rr, chi2.sf(Z2, rr), color=MUTED, lw=1.2, label=r'Equal-spectrum Gaussian law')
a.plot(s['rank'], s.studentized, 'o', color=BLUE, ms=4, label='studentized score')
a.plot(s['rank'], s.normalized, 's', color=ORANGE, ms=4, label='normalized score')
a.set_xscale('log', base=2); a.set_xticks([1, 2, 4, 8, 16, 32]); a.set_xticklabels([1, 2, 4, 8, 16, 32])
a.set_xlabel('rank $r$ of $H$ (equal singular values)'); a.set_ylabel('power at $\\theta=10^4$')
a.set_ylim(-.02, 1.04); a.legend(loc='lower right', fontsize=6.5); a.set_title('(a) Synthetic operators', loc='left', fontsize=8.5)

# (b) size-study graphs: archived largest-strength rate vs theta=inf limit
e = pd.concat([pd.read_csv(R/f'{d}/effective_rank_size.csv') for d in ('out_240', 'out_1000', 'out_5000')
               if (R/f'{d}/effective_rank_size.csv').exists()])
o = pd.read_csv(R/'observed_maxtheta_matched.csv')
rr = pd.read_csv(R/'out_size240/size240_rates.csv')
rr = rr[(rr.method == 'matched_kernel') & (rr.theta == rr.theta.max())]
o = pd.concat([o[o.n != 240], rr])            # n=240: re-run with 1,024 outcomes per graph
e = e.merge(o[['n', 'kind', 'graph', 'mechanism', 'rate']], on=['n', 'kind', 'graph', 'mechanism'], how='left')
a = ax[0, 1]
xs = np.geomspace(1, 2000, 300)
a.plot(xs, chi2.sf(Z2, xs), color=MUTED, lw=1.2, label='equal-spectrum reference (not a bound)')
a.plot(e.reff_H, e.chi2_pred, 'x', color=INK, ms=4.5, mew=.8, label='Gaussian spectral approximation')
a.plot(e.reff_H, e.limit_matched_mc, 'o', color=BLUE, ms=3.5, label='noise-free, finite B=499')
a.plot(e.reff_H, e.rate, 'o', mfc='none', mec=INK, ms=4.5, mew=.7, label='simulated, largest strength')
a.set_xscale('log'); a.set_xlabel(r'$r_{\rm eff}(H)$, size-study graphs'); a.set_ylabel('matched-kernel power')
a.set_ylim(-.02, 1.04); a.legend(loc='lower right', fontsize=6.5); a.set_title('(b) ER and WS(0.02), $n$=240–5000', loc='left', fontsize=8.5)

# (c) design-effective rank is a diagnostic, not a one-curve law
t = pd.read_csv(R/'out_dt/design_topology.csv').dropna(subset=['limit_bern'])
a = ax[1, 0]
a.plot(xs, chi2.sf(Z2, xs), color=MUTED, lw=1.2, label='equal-spectrum reference (not a bound)')
a.plot(t.reff_H, t.limit_bern, 'o', color=BLUE, ms=3.5, label=r'Bernoulli, $x=r_{\rm eff}(H)$')
a.plot(t.reff_HPi, t.limit_fixed, '^', color=ORANGE, ms=4, label=r'fixed count, $x=r_{\rm eff}(H\Pi)$')
for (kind, op), lab in {('SBM_003', 'hard3'): 'SBM(0.03) Hard 3', ('BA', 'tail_0.95'): r'BA tail $\lambda$=0.95'}.items():
    q = t[(t.kind == kind) & (t.operator == op)]
    a.annotate(lab, (q.reff_HPi.mean(), q.limit_fixed.mean()), xytext=(10, 14 if 'BA' in kind else -2), textcoords='offset points', fontsize=6.5, color=INK)
a.set_xscale('log'); a.set_xlim(.9, 80); a.set_xlabel('design-effective rank')
a.set_ylabel('noise-free matched power, finite B'); a.set_ylim(-.02, 1.04)
a.legend(loc='lower right', fontsize=6.5); a.set_title('(c) Eight ensembles, $n$=240', loc='left', fontsize=8.5)

# (d) finite strength: ER, Bernoulli, matched kernel
c = pd.read_csv(R/'out_bank8/bank8.csv', keep_default_na=False)
c = c[(c.design == 'Bernoulli') & (c.kind == 'ER') & (c.bank == 'matched') & (c.theta > 0)]
a = ax[1, 1]
for mech, ls, lab in (('hard3', '-', 'Hard 3'), ('decay', ':', 'decay')):
    for stat, col, nm in (('score', BLUE, 'studentized'), ('normalized', ORANGE, 'normalized')):
        q = c[(c.mechanism == mech) & (c.statistic == stat)].groupby('theta').rate.mean()
        a.plot(q.index, q.values, ls, color=col, marker='o' if stat == 'score' else 's', ms=3, lw=1.5,
               label=f'{nm}, {lab}')
a.legend(loc='center right', fontsize=6.5)
a.set_xscale('log'); a.set_xlabel(r'strength $\theta$'); a.set_ylabel('power')
a.set_ylim(-.02, 1.04); a.set_title('(d) ER, $n$=240, Bernoulli', loc='left', fontsize=8.5)
fig.tight_layout()
fig.savefig(OUT/'fig_detectability.pdf'); fig.savefig(OUT/'fig_detectability.png', dpi=200)
print('saved')
