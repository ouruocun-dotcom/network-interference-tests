"""Assignment-normalized scores with scale-stable zero-kernel handling.

The supplied studies used scores_fast.normalized's absolute 1e-12 cutoff.
This corrected implementation is independently checked, but their full
network simulations have not been rerun using it. Do not silently replace
the supplied reference results with claims about this numerical variant.
"""
import numpy as np


def normalized(y,k,X,mu):
    # Normalizing K first avoids a scale-dependent absolute denominator
    # threshold and preserves the statistic's exact kernel-scale invariance.
    flat=k.reshape(k.shape[0],-1)
    scale=np.max(np.abs(flat),axis=1)
    scaled=np.divide(k,scale[:,None,None],out=np.zeros_like(k),where=scale[:,None,None]>0)
    kf=np.linalg.norm(scaled.reshape(k.shape[0],-1),axis=1)
    unit=np.divide(scaled,kf[:,None,None],out=np.zeros_like(k),where=kf[:,None,None]>0)
    a=np.einsum('rf,kfc->rkc',y,unit)
    ku=np.einsum('rbc,kfc->rbkf',X-mu,unit)
    numer=np.abs(np.einsum('rf,rbkf->rbk',y,ku))
    denom=np.linalg.norm(ku,axis=-1)*np.linalg.norm(a,axis=-1)[:,None,:]
    return np.divide(numer,denom,out=np.zeros_like(numer),where=denom>0)
