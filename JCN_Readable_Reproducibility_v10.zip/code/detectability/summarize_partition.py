"""Summaries for the partition studies (selection among random splits; degree roles)."""
import sys
import numpy as np, pandas as pd
from scipy import stats
from pathlib import Path
R = Path(sys.argv[1])
def ci(x):
    x = np.asarray(x); m = x.mean(); h = stats.t.ppf(.975, len(x)-1)*x.std(ddof=1)/np.sqrt(len(x)); return m, m-h, m+h
out = []
p = pd.read_csv(R/'out_part/partition_power.csv', keep_default_na=False)
w = p.pivot_table(index=['kind', 'graph', 'mechanism', 'statistic'], columns='split', values='rate').reset_index()
for (mech, stat), q in w.groupby(['mechanism', 'statistic']):
    m, lo, hi = ci(q.optimized-q.default)
    out.append(dict(study='selected_vs_default', contrast='optimized-default', mechanism=mech, statistic=stat,
                    base=q.default.mean(), alt=q.optimized.mean(), diff=m, lo=lo, hi=hi, graphs=len(q)))
s = pd.read_csv(R/'out_struct/structured_split.csv', keep_default_na=False)
w = s.pivot_table(index=['kind', 'graph', 'mechanism', 'statistic'], columns='split', values='rate').reset_index()
for alt in ('focal_low_degree', 'focal_high_degree'):
    for (mech, stat), q in w.groupby(['mechanism', 'statistic']):
        m, lo, hi = ci(q[alt]-q.random)
        out.append(dict(study='degree_roles', contrast=f'{alt}-random', mechanism=mech, statistic=stat,
                        base=q.random.mean(), alt=q[alt].mean(), diff=m, lo=lo, hi=hi, graphs=len(q)))
o = pd.DataFrame(out); o.to_csv(R/'partition_summary.csv', index=False)
v = pd.read_csv(R/'out_splitvar/split_variability.csv')
g = v.groupby('kind').rate.agg(['mean', 'std']); g['mc_sd'] = np.sqrt(g['mean']*(1-g['mean'])/256)
g['excess_sd'] = np.sqrt(np.maximum(g['std']**2-g.mc_sd**2, 0)); g.to_csv(R/'split_variability_summary.csv')
pd.set_option('display.width', 200); print(o.round(3).to_string()); print(g.round(3))
