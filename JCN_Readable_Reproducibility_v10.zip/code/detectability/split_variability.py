"""How much does power vary across random balanced splits of the same graph?
For one graph per ensemble, 24 random splits x 256 datasets (Hard 2, theta=0.5,
designated Bernoulli W/G-residual bank, studentized). Seed 2026101014.
Compares the between-split SD of power with the binomial Monte Carlo SD."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
import scores_fast as S
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101014); rows = []; n = 240
for kind in r.KINDS:
    gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, n, gs)
    a = nx.to_numpy_array(g, nodelist=range(n))
    dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
    for si in range(24):
        sp = rng.permutation(n); f, c = np.sort(sp[:120]), np.sort(sp[120:])
        w, eig, u, k, groups, *_ = r.prepare(a, f, c); kk = k[groups['orth_degree_max']]
        h = r.scale(((dist <= 2)*1.)[np.ix_(f, c)])
        rej = 0
        for chunk in range(4):
            X, mu = S.draws(rng, (64, 500, 120), False); y = 0.5*(X[:, 0, :]-mu)@h.T + rng.normal(size=(64, 120))
            rej += int(np.sum(S.rank_p(np.max(S.score_z(y, kk, X, mu, False), axis=2)) <= .05))
        rows.append(dict(kind=kind, split=si, rate=rej/256))
    p = pd.DataFrame(rows); p = p[p.kind == kind]
    mc = np.sqrt(p.rate.mean()*(1-p.rate.mean())/256)
    print(kind, round(p.rate.mean(), 3), 'between-split SD', round(p.rate.std(ddof=1), 3), 'MC SD', round(mc, 3),
          'excess SD', round(np.sqrt(max(p.rate.var(ddof=1)-mc**2, 0)), 3), flush=True)
pd.DataFrame(rows).to_csv(OUT/'split_variability.csv', index=False)
