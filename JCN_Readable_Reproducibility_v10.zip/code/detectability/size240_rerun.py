"""Re-run of the n=240 cells of the Bernoulli size study with 1,024 assignments
per graph (archived study: 64). Same graphs and partitions as seed 2026100934
(stream replayed), same 15-point strength grid, same methods and evaluation code;
fresh assignments and noise from seed 2026101012, B=499."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r, revision_size as size, revision_efficiency3 as eff
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
REPS = int(sys.argv[3]) if len(sys.argv) > 3 else 1024
if REPS <= 0:
    raise ValueError('REPS must be positive')
rng = np.random.default_rng(2026100934); q = np.random.default_rng(2026101012); records = []
n = 240; theta_grid = eff.BASE*np.sqrt(240/n)
for kind in ('ER', 'WS_002'):
    for gi in range(8):
        gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, n, gs)
        split = np.random.default_rng(gs+104729).permutation(n)
        f, c = np.sort(split[:n//2]), np.sort(split[n//2:])
        w, d, hs, diag = size.operators(g, f, c)
        _, _, _, coef = size.coefficients(w, d, f, c, gs)
        for begin in range(0, 64, 16):                      # keep the archived stream aligned
            rng.binomial(1, .4, (16, 500, len(c))); rng.normal(size=(16, len(f)))
        counts = {}
        for begin in range(0, REPS, 32):
            batch = min(32, REPS-begin)
            draws = q.binomial(1, .4, (batch, 500, len(c))).astype(float); noise = q.normal(size=(batch, len(f)))
            nw = size.weights(w, d, f, c, noise, coef)
            for mech, h in hs.items():
                signal = np.asarray(h@(draws[:, 0, :]-.4).T).T
                sw = size.weights(w, d, f, c, signal, coef)
                nn = dict(nw); ss = dict(sw)
                nn['matched_kernel'] = np.array([np.asarray(h.T@noise.T).T]); ss['matched_kernel'] = np.array([np.asarray(h.T@signal.T).T])
                for theta in theta_grid:
                    rej = size.evaluate({k_: nn[k_]+theta*ss[k_] for k_ in nn}, draws)
                    for name, v in rej.items():
                        key = (mech, float(theta), name); counts[key] = counts.get(key, 0)+int(v.sum())
        for (mech, theta, method), cnt in counts.items():
            records.append(dict(n=n, kind=kind, graph=gi, seed=gs, mechanism=mech, theta=theta, method=method,
                                rate=cnt/REPS, rejects=cnt, replicates=REPS, B=499))
        pd.DataFrame(records).to_csv(OUT/'size240_rates.csv', index=False)
        print(kind, gi, flush=True)
frame = pd.DataFrame(records)
eff.summarize(frame, OUT, 'size240', ['n', 'kind', 'mechanism'])
