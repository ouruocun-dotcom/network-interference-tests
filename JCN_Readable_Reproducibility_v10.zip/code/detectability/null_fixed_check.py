"""Independent replication of the fixed-count null for the one-hop score:
WS(1), BA and ER, 10 graphs each x 768 outcomes (23,040), seed 2026101016.
Also evaluates the original round-2 implementation (revision_round2.scores)."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r, revision_round2 as design
import scores_fast as S
rng = np.random.default_rng(2026101016); rows = []
for kind in ('WS_100', 'BA', 'ER'):
    for gi in range(10):
        gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
        a = nx.to_numpy_array(g, nodelist=range(240)); sp = np.random.default_rng(gs+104729).permutation(240)
        f, c = np.sort(sp[:120]), np.sort(sp[120:])
        w, eig, u, k, groups, *_ = r.prepare(a, f, c); kk = k[groups['onehop']]
        rej_new = rej_old = 0
        for chunk in range(12):
            X, mu = S.draws(rng, (64, 500, 120), True); y = rng.normal(size=(64, 120))
            rej_new += int(np.sum(S.rank_p(S.score_z(y, kk, X, mu, True)[:, :, 0]) <= .05))
            zo = design.scores(y, kk, X, mu, True)
            rej_old += int(np.sum(r.rank_p(np.max(np.abs(zo), axis=2)) <= .05))
        rows.append(dict(kind=kind, graph=gi, new=rej_new, old=rej_old, n=768))
        print(kind, gi, rej_new/768, rej_old/768, flush=True)
d = pd.DataFrame(rows); d.to_csv(sys.argv[2], index=False)
print('pooled new', d.new.sum()/d.n.sum(), 'old', d.old.sum()/d.n.sum(), 'N', d.n.sum())
