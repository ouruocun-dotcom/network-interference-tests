"""Bernoulli two-block response, theta=1e4: normalized-score power as m grows
(lattice ties shrink as block sums spread). Seed 2026101007, 500 replicates."""
import sys
from pathlib import Path
import numpy as np, pandas as pd
OUT = Path(sys.argv[1]); rng = np.random.default_rng(2026101007); p = .4; B = 499; R = 500; rows = []
for m in (120, 480, 1920):
    bF = np.repeat([0, 1], m//2); bC = rng.permutation(np.repeat([0, 1], m//2))
    Hb = np.array([[1.0, .3], [.2, .8]]); H = Hb[bF][:, bC]; H *= np.sqrt(m/np.sum(H*H))
    hs = hc = 0
    for _ in range(R):
        U = (rng.random(m) < p) - p; Us = (rng.random((B, m)) < p) - p
        Y = 1e4*H@U + rng.normal(size=m)
        a = H.T@Y; t0 = abs(a@U); hs += (1+np.sum(np.abs(Us@a) >= t0*(1-1e-9)))/(B+1) <= .05
        HU = H@U; HUs = Us@H.T; c0 = abs(Y@HU)/np.linalg.norm(HU)
        nus = np.linalg.norm(HUs, axis=1); cs = np.divide(np.abs(HUs@Y), nus, out=np.zeros(B), where=nus > 1e-12)
        hc += (1+np.sum(cs >= c0*(1-1e-9)))/(B+1) <= .05
    rows.append(dict(m=m, studentized=hs/R, normalized=hc/R)); print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv(OUT/'mesoscale_m.csv', index=False)
