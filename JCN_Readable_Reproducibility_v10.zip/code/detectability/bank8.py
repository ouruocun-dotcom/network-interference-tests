"""Normalized versus studentized banks on all eight n=240 ensembles, both designs.
Six graphs per ensemble and design, 64 datasets per graph and cell, B=499,
common assignments and noise; seed 2026101011."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
import scores_fast as S
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
THETAS = (0.5, 1.0, 2.0, 5.0, 20.0); AMPS = (1.0, 3.0, 6.0)
rng = np.random.default_rng(2026101011); rows = []
for kind in r.KINDS:
    for gi in range(6):
        for fixed in (False, True):
            gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
            a = nx.to_numpy_array(g, nodelist=range(240))
            sp = np.random.default_rng(gs+104729).permutation(240)
            f, c = np.sort(sp[:120]), np.sort(sp[120:])
            w, eig, u, k, groups, *_ = r.prepare(a, f, c)
            dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
            cross = lambda x: x[np.ix_(f, c)]
            ops = {'hard2': r.scale(cross((dist <= 2)*1.)), 'hard3': r.scale(cross((dist <= 3)*1.)),
                   'decay': r.scale(cross(np.exp(-(dist-1)/1.5)))}
            banks = {'onehop': groups['onehop'], 'raw': groups['raw_max'], 'controlled': groups['orth_degree_max']}
            idx = sorted(set(sum(banks.values(), []))); kk = k[idx]; pos = {j: i for i, j in enumerate(idx)}
            X, mu = S.draws(rng, (64, 500, 120), fixed); noise = rng.normal(size=(64, 120))
            kxn = S.kx_norms(kk, X, mu)
            label = 'fixed' if fixed else 'Bernoulli'
            def ev(y, mech, theta, h=None):
                zs = S.score_z(y, kk, X, mu, fixed); cs = S.normalized(y, kk, X, mu, kxn)
                for b, ids in banks.items():
                    cols = [pos[j] for j in ids]
                    for s, t in (('score', zs), ('normalized', cs)):
                        rows.append(dict(design=label, kind=kind, graph=gi, mechanism=mech, theta=theta, bank=b,
                                         statistic=s, rate=float(np.mean(S.rank_p(np.max(t[:, :, cols], axis=2)) <= .05))))
                if h is not None:
                    km = h[None]; kmn = S.kx_norms(km, X, mu)
                    for s, t in (('score', S.score_z(y, km, X, mu, fixed)), ('normalized', S.normalized(y, km, X, mu, kmn))):
                        rows.append(dict(design=label, kind=kind, graph=gi, mechanism=mech, theta=theta, bank='matched',
                                         statistic=s, rate=float(np.mean(S.rank_p(t[:, :, 0]) <= .05))))
            ev(noise, 'null', 0.0)
            for mech, h in ops.items():
                for th in THETAS:
                    ev(th*(X[:, 0, :]-mu)@h.T + noise, mech, th, h)
            for mech in ('threshold', 'independent_cascade'):
                adopt = r.cascade(a, X[:, 0, :], c, mech, rng)[:, f]
                for amp in AMPS:
                    ev(amp*adopt + noise, mech, amp)
            pd.DataFrame(rows).to_csv(OUT/'bank8.csv', index=False)
            print(kind, gi, label, flush=True)
