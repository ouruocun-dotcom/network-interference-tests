"""Check of the archived ER Hard-3 n=240 matched-kernel cell (SI numerics)."""
import sys; sys.path.insert(0, sys.argv[1])  # path to the original code/ folder
import numpy as np, revision_study as r, revision_size as size
rng=np.random.default_rng(2026100934); q=np.random.default_rng(99); tot=0; N=0
for gi in range(8):
    gs=int(rng.integers(0,2**31-1)); g,_=r.graph('ER',240,gs)
    sp=np.random.default_rng(gs+104729).permutation(240); f,c=np.sort(sp[:120]),np.sort(sp[120:])
    w,d,hs,diag=size.operators(g,f,c); h=hs['hard3']
    for begin in range(0,64,16):  # keep archive stream aligned
        rng.binomial(1,.4,(16,500,len(c))); rng.normal(size=(16,len(f)))
    for rep in range(16):
        draws=q.binomial(1,.4,(64,500,len(c))).astype(float)
        signal=np.asarray(h@(draws[:,0,:]-.4).T).T
        b=np.array([np.asarray(h.T@(1e6*signal).T).T])
        tot+=int(size.evaluate({'m':b},draws)['m'].sum()); N+=64
    print(gi, tot/N, flush=True)
