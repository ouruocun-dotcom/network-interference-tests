import numpy as np
def coeffs(m,k):
    d=m*(m-1)*(m-2)*(m-3)
    cf=2*k*(k-1)*(m-k)*(m-k-1)/d
    cg=k*(m-k)*(6*k*k-6*k*m+m*m+m)/d
    ct=k*(k-m)*(4*k*k*m-6*k*k-4*k*m*m+6*k*m+m**3-2*m*m+m)/(m*m*(m-1)**2*(m-2)*(m-3))
    kap=k*(m-k)/(m*(m-1))
    v=cf+max(cg,0)+m*max(ct,0)
    return cf,cg,ct,kap,v,4*v/kap**2
for m in (20,60,120,240,1000,2500,10**5):
    k=int(np.floor(.4*m)); cf,cg,ct,kap,v,c2=coeffs(m,k)
    print(m,k,f"cf={cf:.5f} cg={cg:.5f} ct={ct:.2e} kappa={kap:.5f} v={v:.5f} 4v/k^2={c2:.3f} C={80+c2:.2f}")
# worst case over k for each m
for m in (20,120,1000):
    print(m, max(coeffs(m,k)[5] for k in range(2,m-1)), 'sup over k of 4v/kappa^2')
