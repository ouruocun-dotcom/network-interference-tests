"""Effective-rank audit of the Bernoulli size study (seed 2026100934).

Rebuilds exactly the graphs and focal splits of revision_efficiency3.run_size by
replaying its random-number stream, then for every graph and Hard-2/Hard-3
operator computes
  * the singular spectrum of the scaled FC block H and of H Pi (Pi = column centring),
  * r_eff(H) = ||H||_F^4 / ||H^T H||_F^2,
  * noise-free finite-B calibrated power of the matched kernel (Bernoulli),
    by direct Monte Carlo of the limiting statistics in Proposition 4,
  * the Gaussian weighted-chi-square prediction from the spectrum alone,
  * the theta = infinity power of the raw / W-residual / W,G-residual banks,
and joins the observed largest-strength rates from the archived CSV.
"""
import sys, json, time
from pathlib import Path
import numpy as np, pandas as pd
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r, revision_size as size
from scipy.stats import norm

OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
P = .4; SX = np.sqrt(P*(1-P)); ALPHA = .05; B = 499
MC = int(sys.argv[3]) if len(sys.argv) > 3 else 0  # 0: archived defaults by size
if MC < 0:
    raise ValueError('MC must be nonnegative; 0 selects the archived defaults')
Z = norm.ppf(1-ALPHA/2)

def reff(s):
    s2 = s**2
    return float(s2.sum()**2/np.sum(s2**2))

def chi2_prediction(s, rng, draws=20000):
    s2 = s**2; hits = 0
    for start in range(0, draws, 1000):
        g2 = rng.standard_normal((min(1000, draws-start), len(s)))**2
        q = (g2@s2)**2/(g2@(s2**2)); hits += int(np.sum(q > Z**2))
    return hits/draws

def limit_power_matched(h, rng, reps):
    """Noise-free finite-B test; not a population-calibrated ideal power."""
    m = h.shape[1]; hh = h.T@h; rej = 0
    chunk = max(2, int(2e7//(B*m)))
    for start in range(0, reps, chunk):
        k = min(chunk, reps-start)
        U = (rng.random((k, m)) < P) - P
        Us = (rng.random((k, B, m)) < P) - P
        w = U@hh                                   # (k,m)
        t0 = np.abs(np.sum(w*U, axis=1))
        ts = np.abs(np.einsum('kbm,km->kb', Us, w))
        pv = (1+np.sum(ts >= t0[:, None]-1e-12, axis=1))/(B+1)
        rej += int(np.sum(pv <= ALPHA))
    return rej/reps

def replay(rng, n_c, n_f, reps=64, b=499):
    for begin in range(0, reps, 16):
        count = min(16, reps-begin)
        rng.binomial(1, .4, (count, b+1, n_c)); rng.normal(size=(count, n_f))

rows = []; t0 = time.perf_counter()
rng = np.random.default_rng(2026100934)
mc_rng = np.random.default_rng(20261010)
sizes = [int(x) for x in sys.argv[4].split(',')] if len(sys.argv) > 4 else [240, 1000, 5000]
for n in (240, 1000, 5000):
    for kind in ('ER', 'WS_002'):
        for gi in range(8):
            gs = int(rng.integers(0, 2**31-1))
            if n not in sizes:
                # still consume the stream exactly as the original run did
                split = np.random.default_rng(gs+104729).permutation(n)
                replay(rng, n-n//2, n//2); continue
            g, _ = r.graph(kind, n, gs)
            split = np.random.default_rng(gs+104729).permutation(n)
            f, c = np.sort(split[:n//2]), np.sort(split[n//2:])
            w, d, hs, diag = size.operators(g, f, c)
            _, _, _, coef = size.coefficients(w, d, f, c, gs)
            # theta=inf bank power on fresh Bernoulli draws (64 reps x 499, like the study)
            draws = mc_rng.binomial(1, .4, (64, B+1, len(c))).astype(float)
            bank_power = {}
            for mech, h in hs.items():
                hd = h.toarray()
                s = np.linalg.svd(hd, compute_uv=False)
                hp = hd - hd.mean(axis=1, keepdims=True)      # H Pi: remove column-constant channel
                sp = np.linalg.svd(hp, compute_uv=False)
                signal = np.asarray(h@(draws[:, 0, :]-.4).T).T
                sw = size.weights(w, d, f, c, signal, coef)
                sw['matched_kernel'] = np.array([np.asarray(h.T@signal.T).T])
                rej = size.evaluate(sw, draws)
                row = dict(n=n, kind=kind, graph=gi, seed=gs, mechanism=mech,
                           reff_H=reff(s), reff_HPi=reff(sp), top_energy=float(s[0]**2/np.sum(s**2)),
                           diag_singular_energy=diag[mech]['singular_energy'],
                           limit_matched_mc=limit_power_matched(hd, mc_rng, MC or {240:2000,1000:1000,5000:300}[n]),
                           chi2_pred=chi2_prediction(s, mc_rng))
                for name, v in rej.items():
                    row[f'limit64_{name}'] = float(v.mean())
                rows.append(row)
            pd.DataFrame(rows).to_csv(OUT/'effective_rank_size.csv', index=False)
            print(n, kind, gi, f'{time.perf_counter()-t0:.0f}s', flush=True)
            if n == 5000:
                replay(rng, len(c), len(f))
                continue
            replay(rng, len(c), len(f))
(OUT/'run.json').write_text(json.dumps(dict(seed_replayed=2026100934, mc_seed=20261010, MC=MC, B=B), indent=2))
