"""Check of the archived ER Hard-3 n=240 matched-kernel cell (SI numerics)."""
import sys; sys.path.insert(0, sys.argv[1])  # path to the original code/ folder
import numpy as np, revision_study as r, revision_size as size
rng=np.random.default_rng(2026100934); tot={}; tot2={}
for gi in range(8):
    gs=int(rng.integers(0,2**31-1)); g,_=r.graph('ER',240,gs)
    sp=np.random.default_rng(gs+104729).permutation(240); f,c=np.sort(sp[:120]),np.sort(sp[120:])
    w,d,hs,diag=size.operators(g,f,c); h=hs['hard3']
    for begin in range(0,64,16):
        draws=rng.binomial(1,.4,(16,500,len(c))).astype(float); noise=rng.normal(size=(16,len(f)))
        signal=np.asarray(h@(draws[:,0,:]-.4).T).T
        for theta in (40.0,1e6):
            b=np.array([np.asarray(h.T@(noise+theta*signal).T).T])
            rej=size.evaluate({'m':b},draws)['m']
            tot[theta]=tot.get(theta,0)+int(rej.sum())
        # B=499 fresh reassignments for the same observed assignments
        fresh=np.concatenate([draws[:,:1,:],rng.binomial(1,.4,(16,499,len(c))).astype(float)],axis=1) if False else None
    print(gi,{k:v for k,v in tot.items()},flush=True)
print({k:v/512 for k,v in tot.items()})
