"""Null audit of assignment-normalized banks: 8 ensembles x 3 graphs x 256
outcomes per design (6,144 per design), B=499, seed 2026101005."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
import normalized_scores as cb
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(2026101005); rows = []
for kind in r.KINDS:
    for gi in range(3):
        for fixed in (False, True):
            gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
            a = nx.to_numpy_array(g, nodelist=range(240))
            sp = np.random.default_rng(gs+104729).permutation(240)
            f, c = np.sort(sp[:120]), np.sort(sp[120:])
            w, eig, u, k, groups, *_ = r.prepare(a, f, c)
            banks = {'onehop': groups['onehop'], 'raw': groups['raw_max'], 'controlled': groups['orth_degree_max']}
            rej = {(b, s): 0 for b in banks for s in ('score', 'normalized')}
            for chunk in range(4):
                X, mu = cb.draws(rng, (64, 500, 120), fixed); y = rng.normal(size=(64, 120))
                kx = np.einsum('kfc,rbc->rbkf', k, X-mu); kxn = np.linalg.norm(kx, axis=-1)
                zs = cb.score_z(y, k, X, mu, fixed); cs = cb.cosine(y, k, kx, kxn)
                for b, idx in banks.items():
                    for s, t in (('score', zs), ('normalized', cs)):
                        rej[(b, s)] += int(np.sum(cb.rank_p(np.max(t[:, :, idx], axis=2)) <= .05))
            for (b, s), v in rej.items():
                rows.append(dict(design='fixed' if fixed else 'Bernoulli', kind=kind, graph=gi, bank=b, statistic=s, rate=v/256))
            pd.DataFrame(rows).to_csv(OUT/'null_normalized.csv', index=False)
            print('fixed' if fixed else 'bern', kind, gi, flush=True)
