"""Assignment-normalized (cosine) banks versus the paper's outcome-studentized
score banks, on the paper's n=240 graphs, mechanisms and banks.
Independent seed 2026101002. Two-sided, B=499, analytic Bernoulli/fixed-count."""
import sys
from pathlib import Path
import numpy as np, pandas as pd, networkx as nx
CODE = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(CODE))
import revision_study as r
from scipy import sparse
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
KINDS = sys.argv[3].split(',') if len(sys.argv) > 3 else ['ER', 'WS_002']
GRAPHS, REPS, B, P = 6, 64, 499, .4
THETAS = (0.0, 0.5, 1.0, 2.0, 5.0, 20.0)

def draws(rng, shape, fixed):
    if not fixed:
        return (rng.random(shape) < P).astype(float), P
    m = shape[-1]; k = int(np.floor(P*m)); x = np.zeros(shape)
    np.put_along_axis(x, np.argsort(rng.random(shape), axis=-1)[..., :k], 1.0, axis=-1)
    return x, k/m

def rank_p(t):
    return (np.sum(t[:, 1:] >= t[:, :1]-1e-12, axis=1)+1)/t.shape[1]

def score_z(y, k, X, mu, fixed):
    """paper statistic: a=K'y, Z=a'(x-mu)/sd(a), sd from design (analytic)."""
    a = np.einsum('rf,kfc->rkc', y, k)                       # (R,L,C)
    if fixed:
        m = X.shape[-1]; kk = mu*m
        var = (kk/m)*(1-kk/m)*m/(m-1)*np.sum((a-a.mean(-1, keepdims=True))**2, -1)
    else:
        var = P*(1-P)*np.sum(a*a, -1)
    s = np.einsum('rbc,rkc->rbk', X-mu, a)
    return np.abs(s)/np.sqrt(np.maximum(var, 1e-300))[:, None, :]

def cosine(y, k, kx, kxn):
    """assignment-normalized score: Z_l * ||K_l||_F sd_x / ||K_l (x-mu)||.
    For one kernel its ranks equal those of |cos(y, K(x-mu))|; the factor
    ||y|| ||K_l||_F / ||K_l' y|| (constant over reassignments) puts bank
    components on a common null scale."""
    num = np.abs(np.einsum('rf,rbkf->rbk', y, kx))
    kf = np.sqrt(np.sum(k*k, axis=(1, 2)))
    kty = np.linalg.norm(np.einsum('rf,kfc->rkc', y, k), axis=-1)
    den = kxn*(kty/kf)[:, None, :]
    return np.divide(num, den, out=np.zeros_like(num), where=den > 1e-12)

rng = np.random.default_rng(2026101002); rows = []
for fixed in (False, True):
    for kind in KINDS:
        for gi in range(GRAPHS):
            gs = int(rng.integers(0, 2**31-1)); g, _ = r.graph(kind, 240, gs)
            a = nx.to_numpy_array(g, nodelist=range(240))
            sp = np.random.default_rng(gs+104729).permutation(240)
            f, c = np.sort(sp[:120]), np.sort(sp[120:])
            w, eig, u, k, groups, orth, tails = r.prepare(a, f, c)
            dist = sparse.csgraph.shortest_path(sparse.csr_matrix(a), directed=False)
            cross = lambda x: x[np.ix_(f, c)]
            ops = {'hard2': r.scale(cross((dist <= 2)*1.)), 'hard3': r.scale(cross((dist <= 3)*1.)),
                   'decay': r.scale(cross(np.exp(-(dist-1)/1.5)))}
            X, mu = draws(rng, (REPS, B+1, len(c)), fixed)
            noise = rng.normal(size=(REPS, len(f)))
            banks = {'onehop': groups['onehop'], 'raw': groups['raw_max'],
                     'controlled': groups['orth_degree_max']}
            kx = np.einsum('kfc,rbc->rbkf', k, X-mu); kxn = np.linalg.norm(kx, axis=-1)
            def evaluate(y, mech, theta, matched=None):
                zs = score_z(y, k, X, mu, fixed); cs = cosine(y, k, kx, kxn)
                for name, idx in banks.items():
                    for stat, t in (('score', zs), ('cosine', cs)):
                        rej = rank_p(np.max(t[:, :, idx], axis=2)) <= .05
                        rows.append(dict(design='fixed' if fixed else 'Bernoulli', kind=kind, graph=gi,
                                         mechanism=mech, theta=theta, bank=name, statistic=stat, rate=rej.mean()))
                if matched is not None:
                    km = matched[None]
                    kmx = np.einsum('kfc,rbc->rbkf', km, X-mu)
                    for stat, t in (('score', score_z(y, km, X, mu, fixed)), ('cosine', cosine(y, km, kmx, np.linalg.norm(kmx, axis=-1)))):
                        rej = rank_p(t[:, :, 0]) <= .05
                        rows.append(dict(design='fixed' if fixed else 'Bernoulli', kind=kind, graph=gi,
                                         mechanism=mech, theta=theta, bank='matched', statistic=stat, rate=rej.mean()))
            for mech, h in ops.items():
                for theta in THETAS:
                    if theta == 0 and mech != 'hard2':
                        continue
                    y = theta*(X[:, 0, :]-mu)@h.T + noise
                    evaluate(y, 'null' if theta == 0 else mech, theta, h)
            for mech in ('threshold', 'independent_cascade'):
                adopt = r.cascade(a, X[:, 0, :], c, mech, rng)[:, f]
                for amp in (1.0, 3.0, 6.0):
                    evaluate(amp*adopt+noise, mech, amp)
            pd.DataFrame(rows).to_csv(OUT/'cosine_bank.csv', index=False)
            print('fixed' if fixed else 'bern', kind, gi, flush=True)
