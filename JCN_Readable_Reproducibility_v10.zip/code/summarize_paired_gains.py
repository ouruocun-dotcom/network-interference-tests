#!/usr/bin/env python3
"""Paired graph-clustered power gains from the locked comparator study."""

from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import numpy as np
import pandas as pd
from scipy import stats


SOURCE = LOCKED_RESULTS / "results_submission_comparators" / "replicate_results.csv"
OUTPUT = output_dir("results_submission_comparators") / "paired_gains.csv"


def main() -> None:
    data = pd.read_csv(SOURCE)
    data["reject"] = data.pvalue <= 0.05
    keys = ["graph", "graph_index", "delta", "replicate"]
    wide = data.pivot(index=keys, columns="method", values="reject").reset_index()
    rows = []
    for graph in ("ER", "SBM", "BA"):
        for delta in (0.3, 0.6, 0.85):
            subset = wide[(wide.graph == graph) & (wide.delta == delta)]
            for comparator in ("elc", "score", "one_hop"):
                by_graph = (
                    subset.assign(gain=subset.adaptive.astype(float) - subset[comparator].astype(float))
                    .groupby("graph_index").gain.mean()
                    .to_numpy()
                )
                mean = float(by_graph.mean())
                critical = float(stats.t.ppf(0.975, len(by_graph) - 1))
                half = critical * float(by_graph.std(ddof=1) / np.sqrt(len(by_graph)))
                rows.append(
                    {
                        "graph": graph,
                        "delta": delta,
                        "comparator": comparator,
                        "adaptive_power_gain": mean,
                        "cluster_ci_low": mean - half,
                        "cluster_ci_high": mean + half,
                        "graph_clusters": len(by_graph),
                        "datasets": len(subset),
                    }
                )
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(OUTPUT, index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == "__main__":
    main()
