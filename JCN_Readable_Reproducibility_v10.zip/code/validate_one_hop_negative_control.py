#!/usr/bin/env python3
"""Negative control: orthogonalized tails under a pure one-hop alternative."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from archive_paths import output_dir, LOCKED_RESULTS

import numpy as np

from validate_diffusion_kernel_test import (
    cluster_interval,
    generate_graph,
    normalized_adjacency,
    spectral_kernels,
)


N = 240
GRAPH_REPLICATES = 25
ASSIGNMENTS_PER_GRAPH = 32
RANDOMIZATIONS = 499
PROBABILITY = 0.4
THETA = 1.0
LAMBDAS = (0.0, 0.2, 0.4, 0.6, 0.75, 0.85, 0.92)
OUTPUT = output_dir("results_one_hop_negative_control")


def pvalues(
    y_focal: np.ndarray,
    x_auxiliary: np.ndarray,
    kernels: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    weights = np.einsum("rf,lfa->ral", y_focal, kernels, optimize=True)
    denominator = math.sqrt(PROBABILITY * (1.0 - PROBABILITY)) * np.linalg.norm(
        weights, axis=1
    )
    denominator = np.maximum(denominator, 1e-14)
    observed = np.einsum(
        "ra,ral->rl", x_auxiliary - PROBABILITY, weights, optimize=True
    ) / denominator
    assignments = rng.binomial(
        1,
        PROBABILITY,
        size=(len(y_focal), RANDOMIZATIONS, x_auxiliary.shape[1]),
    ).astype(float)
    randomized = np.einsum(
        "rba,ral->rbl", assignments - PROBABILITY, weights, optimize=True
    ) / denominator[:, None, :]

    def upper(observed_stat: np.ndarray, randomized_stat: np.ndarray) -> np.ndarray:
        return (1 + np.sum(randomized_stat >= observed_stat[:, None], axis=1)) / (
            RANDOMIZATIONS + 1
        )

    local = upper(observed[:, 0], randomized[:, :, 0])
    tail = upper(np.max(observed[:, 1:], axis=1), np.max(randomized[:, :, 1:], axis=2))
    adaptive = upper(np.max(observed, axis=1), np.max(randomized, axis=2))
    return local, tail, adaptive


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    graph_rng = np.random.default_rng(1357911)
    simulation_rng = np.random.default_rng(2468022)
    rows = []
    for kind in ("ER", "SBM", "BA"):
        for graph_index in range(GRAPH_REPLICATES):
            graph_seed = int(graph_rng.integers(0, 2**31 - 1))
            graph = generate_graph(kind, N, graph_seed)
            normalized = normalized_adjacency(graph)
            kernels, _, _ = spectral_kernels(normalized, LAMBDAS)
            split = np.random.default_rng(graph_seed + 104729).permutation(N)
            focal = np.sort(split[: N // 2])
            auxiliary = np.sort(split[N // 2 :])
            cross = kernels[:, focal][:, :, auxiliary].copy()
            local_cross = cross[0]
            local_energy = float(np.sum(local_cross**2))
            for index in range(1, len(cross)):
                coefficient = float(np.sum(cross[index] * local_cross)) / max(
                    local_energy, 1e-14
                )
                cross[index] -= coefficient * local_cross

            local_effect = normalized.copy()
            np.fill_diagonal(local_effect, 0.0)
            local_effect *= math.sqrt(N) / np.linalg.norm(local_effect, ord="fro")
            treatment = simulation_rng.binomial(
                1, PROBABILITY, size=(ASSIGNMENTS_PER_GRAPH, N)
            ).astype(float)
            error = simulation_rng.normal(size=(ASSIGNMENTS_PER_GRAPH, N))
            outcome = (
                0.5 * treatment
                + THETA * ((treatment - PROBABILITY) @ local_effect.T)
                + error
            )
            local_p, tail_p, adaptive_p = pvalues(
                outcome[:, focal], treatment[:, auxiliary], cross, simulation_rng
            )
            for method, values in (
                ("one_hop", local_p),
                ("orthogonal_tail", tail_p),
                ("adaptive", adaptive_p),
            ):
                for replicate, value in enumerate(values):
                    rows.append(
                        {
                            "graph": kind,
                            "graph_index": graph_index,
                            "replicate": replicate,
                            "method": method,
                            "pvalue": float(value),
                        }
                    )

    with (OUTPUT / "replicate_results.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    summary = []
    for kind in ("ER", "SBM", "BA"):
        for method in ("one_hop", "orthogonal_tail", "adaptive"):
            graph_rates = []
            for graph_index in range(GRAPH_REPLICATES):
                values = [
                    row["pvalue"]
                    for row in rows
                    if row["graph"] == kind
                    and row["graph_index"] == graph_index
                    and row["method"] == method
                ]
                graph_rates.append(float(np.mean(np.asarray(values) <= 0.05)))
            lower, upper = cluster_interval(np.asarray(graph_rates))
            result = {
                "graph": kind,
                "method": method,
                "rejection_rate": float(np.mean(graph_rates)),
                "cluster_ci_low": lower,
                "cluster_ci_high": upper,
                "datasets": GRAPH_REPLICATES * ASSIGNMENTS_PER_GRAPH,
            }
            summary.append(result)
            print(json.dumps(result))
    with (OUTPUT / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)


if __name__ == "__main__":
    main()
