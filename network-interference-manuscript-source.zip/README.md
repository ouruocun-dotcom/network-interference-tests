# LaTeX manuscript sources

Title: Spectral geometry and power of randomization tests for network interference

This package contains the main manuscript, Supplementary Information,
cover letter, bibliography, bibliography style and all referenced tables
and figure assets. It does not contain compiled manuscript PDFs, build logs,
internal records or participant data. Figure PDFs, where present, are input
assets and must remain in the figures directory.

## Compile

With a TeX distribution providing XeLaTeX and latexmk:

    latexmk -xelatex main.tex
    latexmk -xelatex supplement.tex
    latexmk -xelatex cover_letter.tex

Alternatively, Tectonic resolves the bibliography automatically:

    tectonic main.tex
    tectonic supplement.tex
    tectonic cover_letter.tex

On Overleaf, upload the package contents and select XeLaTeX. Compile main.tex,
then select supplement.tex or cover_letter.tex as the main document to
produce those documents. Keep all relative table and figure paths unchanged.

jcn_review.bst is a locally adapted bibliography style, not an official OUP
template distribution.

Reproducibility repository:
https://github.com/ouruocun-dotcom/network-interference-tests
